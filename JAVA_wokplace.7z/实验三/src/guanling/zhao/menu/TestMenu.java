/**
 * 

 * @ClassName:     TestMenu.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��10��1�� ����4:51:30
 */

package guanling.zhao.menu;

import java.util.Scanner;

import javax.sql.rowset.CachedRowSet;

public class TestMenu {
	   
    public static void main(String[] args) {
    	int choiceMain;
    	int choiceLogin;
    	int choiceRegist;
    	int userCoun=0;
    	int registFlag=0;
    	int loginFlag=1;
    	String[] userName=new String[10];
    	String[] showName=new String[10];
    	String[] password=new String[10];
    	String[] mail=new String[10];
    	String[] passQuestion=new String[10];
    	String[] passAssur=new String[10];
    	String inputName;
    	String inputPass;
    	String inputAnser;
    	String anserName;
    	String newPassAsrur;
    	Scanner input= new Scanner(System.in);
    
		do {
			Menu.showMainMenu();
			choiceMain=input.nextInt();
			switch (choiceMain) {
			case 1:
				do {
					Menu. showRegistMenu();
				    choiceRegist=input.nextInt();
				    switch (choiceRegist) {
					case 1:
				  
						System.out.println("�������û�����");
					    userName[userCoun]=input.next();
						System.out.println("��������ʾ����");
						showName[userCoun]=input.next();
						System.out.println("���������룺");
					    password[userCoun]=input.next();
						System.out.println("ȷ�����룺");
					    passAssur[userCoun]=input.next();
						System.out.println("���������䣺");
						 mail[userCoun]=input.next();
					
						if( Menu.userNameJudge(userName[userCoun])&& Menu.showNameJudge(showName[userCoun])&&Menu.passwordJudge(password[userCoun], passAssur[userCoun])&&Menu.mailJudge(mail[userCoun])){
							
							passQuestion[userCoun]=Menu.passQuetion();
							if (Menu.arithmetic()) {
								System.out.println("username["+userCoun+"]="+"'"+userName[userCoun]+"'");
								System.out.println("password["+userCoun+"]="+"'"+password[userCoun]+"'");
								registFlag=1;
								userCoun++;
								break;
							}
							else {
								break;
							}
							
						     	
						}
						else {
							break;
						}
					 
					    	
					case 2:	
						do {
							System.out.println("�������û���");
							inputName=input.next();
							System.out.println("���������룺");
							inputPass=input.next();
							
						} while (!Menu.login(userName, password, inputName, inputPass));
						System.out.println("��¼�ɹ���");
						boolean flag=true;
						do {
							Menu.showLoginMenu(showName, userName, inputName);
							choiceLogin=input.nextInt();
							switch (choiceLogin) {
							case 1:
								loginFlag=0;
								flag=false;
								break;
							case 2:
							case 3:
							case 4:
							case 5:
								System.out.println("����ִ��ĳ���ܡ���");
								
								break;

							default:
								break;
							}
						} while (flag);
						
						break;
						
					case 3:
						Menu.showPassQuestion();
						input.nextInt();
						System.out.println("�������û�����");
						anserName=input.next();
					    System.out.println("����𰸣�");
					    inputAnser=input.next();
					   
					    if( Menu.findPassword(userName, passQuestion, anserName, inputAnser)){
					    	String newPassword;
					    	System.out.println("�����������룺");
					    	newPassword=input.next();
					    	System.out.println("ȷ�����룺");
					    	newPassAsrur=input.next();
					    	if(Menu.passwordJudge(newPassword, newPassAsrur)){
					    		Menu.reNewPassord(userName, password, anserName, newPassword);
					    		break;
					    	}
					    
					    	
					    	
					    	break;
					    }
					    else {
							break;
						}
					    

					default:
						break;
					}
					
				} while (registFlag==1&&loginFlag==1);
				
			
			    break;
			case 2:
			case 3:
			case 4:
				System.err.println("�û�δ��¼�����ȵ�¼��");
				break;
			case 5:	
				System.out.println("ллʹ�ã��ټ���");
				System.exit(0);
				break;
			default:
				System.out.println("����������������룡");
				break;
			}
		} while (true);
	}
}
