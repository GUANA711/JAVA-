/*
 * 
 * Author:�Թ���
 * Date:2019.9.27
 * 
 */


package guanling.zhao.convert;
import java.util.MissingFormatArgumentException;
import java.util.Scanner;
import java.lang.NumberFormatException;
import java.nio.charset.MalformedInputException;


public class DoubleConverter {
	double result=0;
	public boolean convert(String value){
		 int i;
		 int length=value.length();
		 int pointCount=0;
		 int pointPlace=0;
		 int[] intNum= new int[length];
		 char[] valueArry=value.toCharArray();
		 boolean isInt=true;
		 for( i=0;i<length;i++){
			 if(valueArry[i]>='0'&&valueArry[i]<='9'){
				 intNum[i]=valueArry[i]-'0';
			 }
			 else if(valueArry[i]=='.'&&pointCount==0){
				 pointPlace=i;
				 pointCount++;
				 intNum[i]='.';
			 }
			 else {
				 isInt=false;
				break;
			}
			 
			
			
			}
		 
			if(isInt==false||pointCount==0||pointPlace==0){
				return false;
			}
			else{
				for(int j=0;j<length;j++){
					if(intNum[j]=='.'){
						continue;
					}
					else if( j<pointPlace){
						result+=intNum[j]*Math.pow(10,pointPlace-j-1);
					}
					else if(j>pointPlace){
						result+=intNum[j]*Math.pow(10, pointPlace-j);
					}
						
				}
				
			 
		       }
		
		    return true;	
	}	
	

			 
		 
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
