package guanling.zhao.frenquenty;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class FindFrenquent {
	 private Map<Character, Double> charaCount=new HashMap<>(); 
	 private Map<Character, Double> charaFren=new HashMap<>(); 
     File file=null;
     int charactorsSum;
	 
	 public FindFrenquent(String myFile){
		 file=new File(myFile);
		 //��ĸƵ�ʳ�ʼ��
		 
		 for(int i=65;i<=90;i++){
			 char word1=(char)i;
			 charaCount.put(word1, 0.0);
		 }
		 for(int j=65;j<=90;j++){
			 char word2=(char)j;
			 charaFren.put(word2, 0.0);
		 }
		 
	 }
	 
	 public  Map<Character, Double> getCharaCount(){
		 return  charaCount;
	 }
	 
	 public  Map<Character, Double> getCharaFren(){
		 return  charaFren;
	 }
	 
	 public  Map<Character, Double> CharactorsCount(){
		 FileReader fileReader=null;
		 char[] word=new char[1];
		 int length;
		 charactorsSum=0;
		 
		 try {
			 
			fileReader=new FileReader(file);
			length=fileReader.read(word);	
            while(length>0){
			   for(char key:charaCount.keySet()){
				   if(word[0]==key||word[0]==key+32){
					   Double tepFren=charaCount.get(key)+1;
					   charaCount.put(key, tepFren);
				   }
				   
			   }
			   length=fileReader.read(word);
			   charactorsSum++;			
			   }
		} catch (IOException e) {
			System.err.println("�ļ����ܲ����ڣ���");
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			try {
				if(fileReader!=null)
					fileReader.close();
			} catch (IOException e2) {
				e2.printStackTrace();
				// TODO: handle exception
			}
		}
		return charaCount;
		 
	 }

	 
	 public void frenPrint(Map<Character,Double> myMap){
		 System.out.println("�ַ�������"+charactorsSum);
		 for(char key:myMap.keySet()){
			 double value=myMap.get(key);
			 String value_str = String.format("%.1f", value);
			 System.out.println(key+":"+value_str+"%");
		 }
	 }
	 
	 public Map<Character, Double> CharactorsFren(){
		 
		 for(char keyCount:charaCount.keySet()){
			 double tempFren=(charaCount.get(keyCount)/charactorsSum)*100;
			 charaFren.put(keyCount, tempFren);
		 }
		 return charaFren;
	 }
	 
   
}
