/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��10��19�� ����14:31:30
 */
package guanling.zhao.frenquenty;

import java.io.File;

public class Test {
   public static void main(String[] args) {
	String myFile="zgl.txt";
	FindFrenquent findFrenquent=new FindFrenquent(myFile);
	findFrenquent.CharactorsCount();
	//findFrenquent.frenPrint(findFrenquent.CharactorsCount());
	findFrenquent.frenPrint(findFrenquent.CharactorsFren());
	
}
}
