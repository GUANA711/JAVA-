package guanling.zhao.menu;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Year;
import java.util.Base64;
import java.util.Scanner;

import javax.rmi.CORBA.Tie;

import guanling.zhao.menu.mood;
import guanling.zhao.menu.weather;

enum weather{sun,cloudy,rain,snow};
enum mood{happy,sad,normal}
public class Diary implements Comparable,DiaryInterface {
	private Date day;
	private String title;
	//private String contents=null;;
	private weather weather;
	private mood mood;
	
    public Diary(Date day,String title,weather weather,mood mood){ 
    	this.day=day;
    	this.title=title+".txt";
    	//this.contents=contents;
    	this.weather=weather;
    	this.mood=mood;
    }
    public Diary(String title){
    	this.weather=weather.cloudy;
    	this.mood=mood.happy;
    	this.day=new Date("2019/00/00");
    	this.title=title;
    }
    
     public String toString(){
    	return day.getDate()+" "+weather+" "+mood+" "+title;
    }
     
     public String getTitle(){
    	 return title;
     }
     
     public Date getDate(){
    	 return this.day;
     }
     
    

	@Override
	public int compareTo(Object otherDiary) {
		Diary myDiary=(Diary)otherDiary;
	
	    if(day.getYear()==myDiary.getDate().getYear()){
	    	if(day.getMonth()==myDiary.getDate().getMonth()){
	    		return day.getdday()-myDiary.getDate().getdday();
	    	}
	    	else {
				return day.getMonth()-myDiary.getDate().getMonth();
			}
	    }
	    else {
			return day.getYear()-myDiary.getDate().getYear();
		}
		
		
		
	}

	@Override
	public String writeContents() {
		// TODO Auto-generated method stub
		 
		 Scanner input=new Scanner(System.in);	
         FileWriter fWriter=null;
         BufferedWriter bufferedWriter=null;
         
         try {
			 File file= new File(title);
        	 fWriter=new FileWriter(file);
        	 bufferedWriter=new BufferedWriter(fWriter);
        	 System.out.println("�������ռ�����('##'����)");
        	 String contents=input.next();
        	 String temp="##";
        	 bufferedWriter.write(this.toString());
        	 bufferedWriter.newLine();
        	 while(!contents.equals(temp)){
        		 
            	bufferedWriter.write(contents+' '); 
            	contents=input.next();
        	 }
        	
        	
        	 
        	 
		} catch (IOException e) {
			
			e.printStackTrace();
			// TODO: handle exception
		}finally{
			
			try {
				if(bufferedWriter!=null)
					bufferedWriter.close();
			} catch (IOException e1) {
				// TODO: handle exception
				e1.printStackTrace();
			}
			try {
				if(fWriter!=null)
					fWriter.close();
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}

		return null;
	}

	@Override
	 public void readContFromFile() {
		FileReader fileReader=null;
		BufferedReader bufferedReader=null;
		Scanner input=new Scanner(System.in);	
		String contents;
		try {
			File file= new File(title);
            fileReader=new FileReader(file);
            bufferedReader=new BufferedReader(fileReader);
            contents=bufferedReader.readLine();
            while(contents!=null){
            	System.out.println(contents);
            	contents=bufferedReader.readLine();
            	
            	
            }
			
		} catch (IOException e) {
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			
			try {
				if(bufferedReader!=null)
					bufferedReader.close();
			} catch (IOException e1) {
				// TODO: handle exception
				e1.printStackTrace();
			}
			try {
				if(fileReader!=null)
					fileReader.close();
			} catch (IOException e2) {
				e2.printStackTrace();
				// TODO: handle exception
			}
		}
		// TODO Auto-generated method stub
		
	}
	
	//�м���'f'���м�ƪ����
	public static void fileAdd(Diary myDiary){
		BufferedWriter bufferedWriter=null;
		FileWriter fileWriter=null;
		 try {
			 String diName=myDiary.getTitle();
			 File myFile=new File("FileSave.txt");
			 fileWriter=new FileWriter(myFile,true);
			 bufferedWriter=new BufferedWriter(fileWriter);
			 bufferedWriter.write(diName);
			 bufferedWriter.newLine();
			 
			 } catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			try {
				if(bufferedWriter!=null)
					bufferedWriter.close();
			} catch (IOException e1) {
				// TODO: handle exception
				e1.printStackTrace();
			}
			try {
				if(fileWriter!=null)
					fileWriter.close();
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		
	}
	
	
	
     
     
	

}
