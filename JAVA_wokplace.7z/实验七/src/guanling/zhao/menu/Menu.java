package guanling.zhao.menu;

import java.util.ArrayList;




public class Menu {
 
   private ArrayList<String> menuCotent=new ArrayList<String>();;
   private int rowCount;
   
   public Menu(ArrayList<String> stringArry){
	   rowCount=stringArry.size();
	   int length=rowCount;
	   int index=0;
	   while(length>0){
			  
			  menuCotent.add(stringArry.get(index));
			  //System.out.println(count+":"+ content);
			  length--;
			  index++;
			  
		  }
	  
   }
   
   
   //��̬���ɲ˵�
   
   
   public void munePrint(){
	   int tempCount=1;
	   int index=0;
	   while(tempCount<=rowCount){
		   System.out.println(tempCount+":"+menuCotent.get(index) );   
		   tempCount++;
		   index++;
		   
	   }
	   System.out.println("��ѡ��");
	  
   }
   
   
}
