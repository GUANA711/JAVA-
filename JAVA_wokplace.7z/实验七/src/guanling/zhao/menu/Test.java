/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��11��19�� ����9:51:30
 */
package guanling.zhao.menu;
import java.util.Scanner;
import java.util.TreeSet;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		ArrayList<String> firstMenuContents=new ArrayList<String>();
		firstMenuContents.add("��¼ϵͳ");
		firstMenuContents.add("ϵͳ����");
		firstMenuContents.add("д�ռ�");
		firstMenuContents.add("�����ռ�");
		firstMenuContents.add("�˳�ϵͳ");
		
		ArrayList<String> secondMenuContents=new ArrayList<String>();
		secondMenuContents.add("�鿴�ռ��б� ");
		secondMenuContents.add("������һ��˵� ");
		
		Menu firstMenu=new Menu(firstMenuContents);
    	Menu secondMenu=new Menu(secondMenuContents);
    	
    	ArrayList<String> diArrayList=new ArrayList<String>();
    	
		
    	
		boolean exit=false;
		 
		do {
	        firstMenu.munePrint();
	        int mainChoice=input.nextInt();
	        switch (mainChoice) {
			case 1:
				
				break;
			case 2:
				break;
			case 3:
				System.out.println("�������ռ���Ŀ");
				String title=input.next();
						
				System.out.println("������ʱ�䣨YYY/MM/DD��:");
				String date=input.next();
				Date myDate=new Date(date);
				
				System.out.println("��ѡ������:");
				mood myMood;
				System.out.println("1.happy  2.sad   3.normal");
				int moodChioce=input.nextInt();
				switch (moodChioce) {
				case 1:
					myMood=mood.happy;
					
					break;
				case 2:
					myMood=mood.sad;break;
			    case 3:
			    	myMood=mood.normal;break;
				default:
					System.out.println("�������Ĭ��Ϊhappy");
					myMood=mood.happy;
					break;
				}
				
				System.out.println("��ѡ������:");
				weather myWeather;
				System.out.println("1.sun  2.cloudy  3.rain  4.snow");
				int weatherChoice=input.nextInt();
				switch (weatherChoice) {
				case 1:
					myWeather=weather.sun;
					
					break;
				case 2:
					myWeather=weather.cloudy;break;
				case 3:
					myWeather=weather.rain;break;
				case 4:
				    myWeather=weather.snow;break;

				default:
					System.out.println("�������Ĭ��Ϊsun");
					myWeather=weather.sun;
					break;
				}
				
				Diary myDiary=new Diary(myDate, title, myWeather, myMood);
				myDiary.writeContents();
				//diarySet.add(myDiary);
				Diary.fileAdd(myDiary);
				
				break;
			case 4:
				secondMenu.munePrint();
				int secondChoice=input.nextInt();
				switch (secondChoice) {
				case 1:
				  FileReader fileReader=null;
				  BufferedReader bufferedReader=null;
				  int count=1;
				  try {
					fileReader=new FileReader("FileSave.txt");
					bufferedReader=new BufferedReader(fileReader);
					String fileName=bufferedReader.readLine();
					while (fileName!=null) {
						//fileName=bufferedReader.readLine();	
						System.out.println(count+":"+fileName);
						diArrayList.add(fileName);
						fileName=bufferedReader.readLine();
						count++;
						
						
					}
				 System.out.println("��ѡ���ռǣ�");
				 int diaryChoice=input.nextInt();
				 Diary tmpDiary=new Diary(diArrayList.get(diaryChoice-1));
				 tmpDiary.readContFromFile();
				 
				
				 
				 
				} catch (IOException e) {
					e.printStackTrace();
					// TODO: handle exception
				}finally {
					try {
						if(bufferedReader!=null)
							bufferedReader.close();
					} catch (IOException e1) {
						// TODO: handle exception
						e1.printStackTrace();
					}
					try {
						if(fileReader!=null)
							fileReader.close();
					} catch (IOException e2) {
						e2.printStackTrace();
						// TODO: handle exception
					}
				}
					
					break;
				case 2:
					break;
				default:
					System.out.println("���������");
					break;
				}
				break;
			case 5:
				exit=true;
				break;
			default:
				break;
			}
			
		} while (!exit);
	}
	
}
