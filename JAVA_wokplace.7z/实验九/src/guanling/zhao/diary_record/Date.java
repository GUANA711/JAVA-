package guanling.zhao.diary_record;

import java.util.ArrayList;



public class Date {
    private  String date;
    private ArrayList<Integer> dateIntArry=new ArrayList<Integer>();
    private int year=0;
    private int month=0;
    private int dday=0; 
    private boolean isTrue=true;
    
    public Date(String date){
    	char[] dateArry=new char[10];
    	dateArry=date.toCharArray();
    	this.date=date;
    	int length=date.length();
    	int index=0;
    	
    	if(length!=10){
    		isTrue=false;
    	}
    	else{
    		while(length>0){
        		if(dateArry[index]>='0'&&dateArry[index]<='9')
        			dateIntArry.add((int)dateArry[index]-48);
        			length--;
        		    index++;
        	}
        	
        	
        	
        	for(int i=0;i<4;i++){
    			
    			year=year*10+dateIntArry.get(i);
    		}
    		for(int j=4;j<6;j++){
    			month=month*10+dateIntArry.get(j);
    		}
    		for(int k=6;k<8;k++){
    			dday=dday*10+dateIntArry.get(k);
    		}
    	}
    	
    }
    public void  datePrint(){
    	for(int i:dateIntArry){
    		System.out.println(i);
    	}
    }
    
    public String getDate(){
    	return date;
    }
    
    public int getYear(){
    	return year;
    }
    public int getMonth(){
    	return month;
    }
    public int getdday(){
    	return dday;
    }
    public ArrayList<Integer> getDateIntArry(){
    	return dateIntArry;
    }
    //���ڸ�ʽΪ��YYYY/MM/DD
     public  boolean dateJudge( ){
    	 String year;
    	 String month;
    	 String day;
        
          char[] dateArry=new char[10];
     	 dateArry=date.toCharArray();
     	 if(!isTrue) return false;
          //System.out.println(date.substring(4, 5)+date.substring(7, 8));
    	 if(dateArry[4] != '-' || dateArry[7] != '-'){
    		 //System.out.println("��ʽ����");
    		 return false;
    	 }
    	 //int int_year=Integer.parseInt(year);
    	 year=date.substring(0, 4);
    	 month=date.substring(5,7);
    	 day=date.substring(8,10);
    	
    	 for(int i=0;i<date.length();i++){
    		 if(i==4 || i==7) continue;
    		 if(dateArry[i]<'0' || dateArry[i]> '9') return false;
    		
    			 
    	 }
    	
    	 int int_month=Integer.parseInt(month);
    	 int int_day=Integer.parseInt(day);
    	 if(int_month>12||int_month<1) return false;
    	 if(int_day<1||int_day>31) return false;
    		 
    	 
    	
    	 
    	 return true;
    	 
     }
}
