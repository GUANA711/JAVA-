/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��12��10�� ����4:51:30
 */
package guanling.zhao.diary_record;


import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.StyledEditorKit.BoldAction;
import javax.swing.text.html.HTMLDocument.HTMLReader.IsindexAction;

import org.omg.CORBA.PUBLIC_MEMBER;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.Book;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class Test {
      private JFrame mainJFrame=new JFrame("�ճ̼�¼");
      //����������
     
      private JList diaryList;
      private DefaultListModel<String> diaryModel=new DefaultListModel();
      private JButton addBt=new JButton("����");
      private JButton delBt=new JButton("ɾ��");
      private JButton empBt=new JButton("���");
      //�����Ҳ����
      private JLabel dateJLabel=new JLabel("*����:");
      private JLabel timeJLabel=new JLabel("*ʱ��:");
      private JLabel eventJLabel=new JLabel("*�¼�:");
      private JLabel placeJLabel=new JLabel("�ص�:");
      private JLabel joinerJLabel=new JLabel("������:");
      private JLabel tipJLabel=new JLabel("��ע:");
      
      private JTextField dateTextField=new JTextField(10);
      private JTextField timeTextField=new JTextField();
      private JTextField eventTextField=new JTextField();
      private JTextField placeTextField=new JTextField();
      private JTextField joinerTextField=new JTextField();
      private JTextArea  tipTextArea=new JTextArea();
      
      private JButton editBt=new JButton("�༭");
      private JButton cancelBt=new JButton("ȡ��");
      private JButton confirmBt=new JButton("ȷ��");
      
      //private ArrayList<Diary> diaryArry=new ArrayList<Diary>();//�����¼�
      private Map<String, Diary> diaryMap=new HashMap<String, Diary>();
      private boolean isAdd=true;
      public Test(){
    	  init();
      }
      
      public void init(){
    	 //�������� 
    	  mainJFrame.setSize(800, 600);
    	  mainJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	  int windowHight=mainJFrame.getHeight();
    	  int windowWith=mainJFrame.getWidth();
    	  Toolkit kit=Toolkit.getDefaultToolkit();
    	  int screenHight=kit.getScreenSize().height;
    	  int screenWith=kit.getScreenSize().width;
    	  mainJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);//���ô��ھ�����ʾ
    	  //mainJFrame.setLocationRelativeTo(null);
    	  
    	  
    	  GridBagLayout gridBagLayout=new GridBagLayout();
    	  JPanel leftJPanel=new JPanel(gridBagLayout);
    	  JPanel rightJPanel=new JPanel(gridBagLayout);
          leftJPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
          rightJPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
    	  JSplitPane splitPane=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftJPanel, rightJPanel);
    	  splitPane.setResizeWeight(0.5);//ָ�������ÿؼ��Ĵ�С���൱�ڰٷֱ� 
    	  splitPane.setDividerLocation(0.4);
    	  //splitPane.setDividerSize(2);
    	  splitPane.setContinuousLayout(true);//���������ʾ
    	  //mainJFrame.setContentPane(splitPane);
    	 
    	  mainJFrame.add(splitPane);
    
    	 
    	  //��˳���������
    	  
    	  diaryList=new JList<>(diaryModel);
    	  diaryList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    	 
    	  leftJPanel.add(diaryList);
    	  leftJPanel.add(addBt);
    	  leftJPanel.add(delBt);
    	  leftJPanel.add(empBt);
    	  
    	  
    	  rightJPanel.add(dateJLabel);
          rightJPanel.add(dateTextField);
          rightJPanel.add(timeJLabel);
          rightJPanel.add(timeTextField);
          rightJPanel.add(eventJLabel);
          rightJPanel.add(eventTextField);
          rightJPanel.add(placeJLabel);
          rightJPanel.add(placeTextField);
          rightJPanel.add(joinerJLabel);
          rightJPanel.add(joinerTextField);
          rightJPanel.add(tipJLabel);
          rightJPanel.add(tipTextArea);
          rightJPanel.add(editBt);
          rightJPanel.add(cancelBt);
          rightJPanel.add(confirmBt);
          
          GridBagConstraints myGridBagConstraints= new GridBagConstraints();
          myGridBagConstraints.fill=GridBagConstraints.BOTH;  //��䷽ʽ��ˮƽ+��ֱ
          
          //diarylist
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth= GridBagConstraints.REMAINDER;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=1;
          gridBagLayout.setConstraints(diaryList, myGridBagConstraints);
          
         
          //addbt
          myGridBagConstraints.insets=new Insets(40, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(addBt, myGridBagConstraints);
          
          //deleBt
          myGridBagConstraints.insets=new Insets(40, 10, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(delBt, myGridBagConstraints);
          
          //emptBT
          myGridBagConstraints.insets=new Insets(40, 10, 20, 10);
          myGridBagConstraints.gridx=2;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(empBt, myGridBagConstraints);
          
          //dateLabel
          myGridBagConstraints.insets=new Insets(10, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(dateJLabel, myGridBagConstraints);
           
          //dateTextField
          myGridBagConstraints.insets=new Insets(10, 0, 20, 10);
          
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth =3;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(dateTextField, myGridBagConstraints);
          
        //timeLabel
          myGridBagConstraints.gridx=4;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(timeJLabel, myGridBagConstraints);
          
        //timeTextFiled
          myGridBagConstraints.gridx=5;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(timeTextField, myGridBagConstraints);
          
          //eventLabel
          myGridBagConstraints.insets=new Insets(0, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(eventJLabel, myGridBagConstraints);
          
        //eventTextField
          myGridBagConstraints.insets=new Insets(0, 0, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(eventTextField, myGridBagConstraints);
          
        //placeLbel
          myGridBagConstraints.insets=new Insets(3, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=2;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(placeJLabel, myGridBagConstraints);
          
          //placeTextField
          myGridBagConstraints.insets=new Insets(0, 0, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=2;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(placeTextField, myGridBagConstraints);
          
          //joinerLabel
          myGridBagConstraints.insets=new Insets(0, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=3;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(joinerJLabel, myGridBagConstraints);
          
        //joinerTxtField
          myGridBagConstraints.insets=new Insets(0, 0, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=3;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(joinerTextField, myGridBagConstraints);
          
         
          mainJFrame.setVisible(true);
    	 
        //tipLbel
          myGridBagConstraints.insets=new Insets(30, 10, 30, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=4;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(tipJLabel, myGridBagConstraints);
    	 
        //tipTxtArea
          myGridBagConstraints.insets = new Insets(0, 0, 0, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=4; 
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridheight=2;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 1;
          gridBagLayout.setConstraints(tipTextArea, myGridBagConstraints);
          
//        //editBT
         
          myGridBagConstraints.insets=new Insets(10, 5, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(editBt, myGridBagConstraints);
          
          //CANCELbt
          myGridBagConstraints.insets=new Insets(10, 40, 20, 10);
          myGridBagConstraints.gridx=7;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(cancelBt, myGridBagConstraints);
          
          //confirmBT
          myGridBagConstraints.insets=new Insets(10, 0, 20, 5);
          myGridBagConstraints.gridx=8;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(confirmBt, myGridBagConstraints);
          
          mainJFrame.pack();
          //�༭��Ĭ�ϲ��ܱ༭ 
        dateTextField.setEnabled(false);
      	timeTextField.setEnabled(false);
      	eventTextField.setEnabled(false);
      	placeTextField.setEnabled(false);
      	joinerTextField.setEnabled(false);
      	tipTextArea.setEnabled(false);		
          
          
          //addBT�¼�
         
          
          //deleBT�¼�
          delBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(diaryList.isSelectionEmpty()){
					
					JOptionPane.showMessageDialog(leftJPanel.getComponent(0), "����ѡ��Ҫɾ�����г̣�");
				}
				if(diaryModel.isEmpty()){
					JOptionPane.showMessageDialog(leftJPanel.getComponent(0),"�б���Ϊ���ˣ�");
				}
				if(diaryList.getSelectedIndex()>=0){
		            int choice=JOptionPane.showConfirmDialog(leftJPanel, "ȷ��ɾ����");
		            if(choice==0){
		            	diaryModel.remove(diaryList.getSelectedIndex());
		            	dateTextField.setText(" ");
		            	timeTextField.setText(" ");
		            	eventTextField.setText(" ");
		            	placeTextField.setText(" ");
		            	joinerTextField.setText(" ");
		            	tipTextArea.setText(" ");		            }
					
				}
			}
		});
          
          empBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(diaryModel.isEmpty()){
					JOptionPane.showMessageDialog(leftJPanel.getComponent(0),"�б���Ϊ���ˣ�");
				}
				else {
					int choice=JOptionPane.showConfirmDialog(leftJPanel, "ȷ��Ҫ����б���");
					 if(choice==0){
			            	diaryModel.clear();
			            	dateTextField.setText("");
			            	timeTextField.setText("");
			            	eventTextField.setText("");
			            	placeTextField.setText("");
			            	joinerTextField.setText("");
			            	tipTextArea.setText("");		            }
						
					}
					
				}
				
			
		});
          
        addBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				    dateTextField.setEnabled(true);
			      	timeTextField.setEnabled(true);
			      	eventTextField.setEnabled(true);
			      	placeTextField.setEnabled(true);
			      	joinerTextField.setEnabled(true);
			      	tipTextArea.setEnabled(true);
			      	diaryList.setSelectedIndex(10);
			      	isAdd=true;	
				
			}
		});
        
        confirmBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				boolean dateJudge=true;
				boolean timeJudge=true;
				boolean evwntJudege=true;
				
				
				//System.out.print(eventTextField.getText());
				
				
				Date myDate=new Date(dateTextField.getText());
		      	if(!myDate.dateJudge()){
		      		JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"���ڸ�ʽ����");
		      		dateJudge=false;
		      	}
		      	
		      	Time myTime=new Time(timeTextField.getText());
		    	if(!myTime.timeJudege()){
		      		JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"ʱ���ʽ����");
		      		timeJudge=false;
		      	}
		    	
		    	if(eventTextField.getText().equals("")){
		    		JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"�¼�����Ϊ��");
		    		evwntJudege=false;
		    	}
		    	if(dateJudge&&timeJudge&&evwntJudege){
		    		//����
		    		if(isAdd){
		    			Diary myDiary=new Diary(dateTextField.getText(), timeTextField.getText(), eventTextField.getText(), placeTextField.getText(), joinerTextField.getText(), tipTextArea.getText());
			    		diaryMap.put(myDiary.toString(), myDiary);
			    		diaryModel.addElement(myDiary.toString());
			    		//System.out.print("zgl"+diaryModel.getElementAt(0));
		    		}
		    		//�༭
		    		else {
		    			String key=(String)diaryList.getSelectedValue();
		    			Diary mydiary=diaryMap.get(key);//�޸�֮ǰ��diary
		    			Diary newDiary;//�޸�֮���diary
		    			int choice=diaryList.getSelectedIndex();
		    			if(!dateTextField.getText().equals(mydiary.getDate())){
		    				diaryMap.get(key).setDate(dateTextField.getText());
		    				newDiary=diaryMap.get(key);
		    				JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"�����޸�Ϊ��"+dateTextField.getText());
		    				diaryModel.setElementAt(newDiary.toString(), choice);
		    				diaryMap.remove(key);
		    				diaryMap.put(newDiary.toString(),newDiary);
		    			}
		    			if(!timeTextField.getText().equals(mydiary.getTime())){
		    				diaryMap.get(key).setTime(timeTextField.getText());
		    				newDiary=diaryMap.get(key);
		    				JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"ʱ���޸�Ϊ��"+timeTextField.getText());
		    				diaryModel.setElementAt(newDiary.toString(), choice);
		    				diaryMap.remove(key);
		    				diaryMap.put(newDiary.toString(),newDiary);
		    			}
		    			if(!eventTextField.getText().equals(mydiary.getEvent())){
		    				diaryMap.get(key).setEvent(eventTextField.getText());
		    				newDiary=diaryMap.get(key);
		    				JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"�¼��޸�Ϊ��"+eventTextField.getText());
		    				diaryModel.setElementAt(newDiary.toString(), choice);
		    				diaryMap.remove(key);
		    				diaryMap.put(newDiary.toString(),newDiary);
		    			}
		    			if(!placeTextField.getText().equals(mydiary.getPlace())){
		    				diaryMap.get(key).setPlace(placeTextField.getText());
		    				JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"�ص��޸�Ϊ��"+placeTextField.getText());
		    			}
		    			if(!joinerTextField.getText().equals(mydiary.getJoiner())){
		    				diaryMap.get(key).setJoiner(joinerTextField.getText());
		    				JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"�������޸�Ϊ��"+joinerTextField.getText());
		    			}
		    			if(!tipTextArea.getText().equals(mydiary.getTip())){
		    				diaryMap.get(key).setTipd(tipTextArea.getText());
		    				JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"��ע�޸�Ϊ��"+tipTextArea.getText());
		    			}
		    			
		    			
					}
		    		
		    		
		    		dateTextField.setText("");
	            	timeTextField.setText("");
	            	eventTextField.setText("");
	            	placeTextField.setText("");
	            	joinerTextField.setText("");
	            	tipTextArea.setText("");	
		    		dateTextField.setEnabled(false);
			      	timeTextField.setEnabled(false);
			      	eventTextField.setEnabled(false);
			      	placeTextField.setEnabled(false);
			      	joinerTextField.setEnabled(false);
			      	tipTextArea.setEnabled(false);
		    	
		    	
		        	
		    	}
			}
		});
        
        diaryList.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(!e.getValueIsAdjusting()){//�������if����õ������¼���Ϊʲô��
					String key=(String)diaryList.getSelectedValue();
			
					
			  
			    for(String myKey:diaryMap.keySet()){
			    	if(myKey.equals(key)){
			    		 Diary choiceDiary=diaryMap.get(key);
			    		  dateTextField.setText(choiceDiary.getDate());
							timeTextField.setText(choiceDiary.getTime());
							eventTextField.setText(choiceDiary.getEvent());
							placeTextField.setText(choiceDiary.getPlace());
							joinerTextField.setText(choiceDiary.getJoiner());
							tipTextArea.setText(choiceDiary.getTip());
			    	}
			    }
		         
						
				
				
				}
			}
		});
        
        cancelBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dateTextField.setEnabled(false);
		      	timeTextField.setEnabled(false);
		      	eventTextField.setEnabled(false);
		      	placeTextField.setEnabled(false);
		      	joinerTextField.setEnabled(false);
		      	tipTextArea.setEnabled(false);
		      	
		      	String key=(String)diaryList.getSelectedValue();
				
				Diary choiceDiary=diaryMap.get(key);
				dateTextField.setText(choiceDiary.getDate());
				timeTextField.setText(choiceDiary.getTime());
				eventTextField.setText(choiceDiary.getEvent());
				placeTextField.setText(choiceDiary.getPlace());
				joinerTextField.setText(choiceDiary.getJoiner());
				tipTextArea.setText(choiceDiary.getTip());
			}
		});
        
        editBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dateTextField.setEnabled(true);
		      	timeTextField.setEnabled(true);
		      	eventTextField.setEnabled(true);
		      	placeTextField.setEnabled(true);
		      	joinerTextField.setEnabled(true);
		      	tipTextArea.setEnabled(true);
		      	isAdd=false;
		      	
		      	
			}
		});
          
        
          
      }
     
     
      
      public static void main(String[] args) {
		Test myTest=new Test();
		
		
		
	}
}
