package guanling.zhao.diary_record;

import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Year;
import java.util.Base64;
import java.util.Scanner;

import javax.naming.event.EventContext;
import javax.print.attribute.standard.RequestingUserName;
import javax.rmi.CORBA.Tie;

import guanling.zhao.diary_record.mood;
import guanling.zhao.diary_record.weather;

enum weather{sun,cloudy,rain,snow};
enum mood{happy,sad,normal}
public class Diary   {
	
	private String date;
	private String time;
	private String event;
	private String place=null;
	private String joiner=null;
	private String tip=null;
	
	public Diary(String date,String time,String event,String place,String joiner,String tip){
		this.date=date;
		this.time=time;
		this.event=event;
		this.place=place;
		this.joiner=joiner;
		this.tip=tip;
		
	
	}
	
	public String toString(){
		return date+" "+time+" "+event;
	}
    
	public String getDate(){
		return date;
	}
	
	public String getTime(){
		return time;
	}
    public String getEvent(){
    	return event;
    }
    public String getPlace(){
    	return place;
    }
    public String getJoiner(){
    	return joiner;
    }
    public String getTip(){
    	return tip;
    }
    
    
    
   
	public void setDate(String date){
	    this.date=date;	
	}
	public void setTime(String time){
		this.time=time;
	}
	public void setEvent(String event){
		this.event=event;
	}
	public void setPlace(String place){
		 this.place=place;
	}
	public void setTipd(String tips){
		this.tip=tips;
	}
	public void setJoiner(String joiner){
		this.joiner=joiner;
	}
	
     
	

}
