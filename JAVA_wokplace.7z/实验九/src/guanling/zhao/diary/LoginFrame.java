package guanling.zhao.diary;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.omg.CORBA.PRIVATE_MEMBER;

public class LoginFrame {
	private Font titleFont=new Font("����",Font.PLAIN,32);
	private Font userLabelFont=new Font("����",Font.PLAIN,20);
	private JFrame loginJFrame=new JFrame("Login");
	private JLabel titleJLabel=new JLabel("Guan A's Diary System");
	private JLabel userjLabel=new JLabel("�û���");
	private JLabel passJLabel=new JLabel("��  ��");
    private JTextField userJTextField=new JTextField();
    private JTextField passJTxtField=new JTextField();
    private JButton registJButton=new JButton("ע��");
    private JButton loginJButton=new JButton("��¼");
    private JButton forgetJButton=new JButton("��������");
    
    public LoginFrame(){
    	init();
    }
    
    public void init(){
    	
     
    	
      
    	
      loginJFrame.setSize(500, 300);
      loginJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
   	  int windowHight= loginJFrame.getHeight();
   	  int windowWith= loginJFrame.getWidth();
   	  Toolkit kit=Toolkit.getDefaultToolkit();
   	  int screenHight=kit.getScreenSize().height;
   	  int screenWith=kit.getScreenSize().width;
   	  loginJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);
   	 
   	 GridBagLayout myGridBagLayout=new GridBagLayout();
   	 JPanel mainJPanel=new JPanel(myGridBagLayout);
   		
   	 
//   	 ImageIcon img = new ImageIcon("����"+ ".png");//���Ǳ���ͼƬ
//     JLabel imgLabel = new JLabel(img);//������ͼ���ڱ�ǩ�
//     loginJFrame.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));//ע�������ǹؼ�����������ǩ���ӵ�jfram��LayeredPane����
//     imgLabel.setBounds(0,0,img.getIconWidth(), img.getIconHeight());//���ñ�����ǩ��λ��
//     Container cp=loginJFrame.getContentPane();
//     cp.setLayout(new BorderLayout());
//     ((JPanel)cp).setOpaque(false);
  	 
   	 
   	
   	 titleJLabel.setFont(titleFont);
   	 userjLabel.setFont(userLabelFont);
   	 passJLabel.setFont(userLabelFont);
   	 mainJPanel.add(titleJLabel);
   	 mainJPanel.add(userjLabel);
   	 mainJPanel.add(userJTextField);
   	 mainJPanel.add(passJLabel);
   	 mainJPanel.add(passJTxtField);
   	 mainJPanel.add(registJButton);
   	 mainJPanel.add(loginJButton);
   	 mainJPanel.add(forgetJButton);
   	 
   	 loginJFrame.add(mainJPanel);
   	 
   	//loginJFrame.setVisible(true);
   	GridBagConstraints myGridBagConstraints= new GridBagConstraints();
   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
   	
   	//title
   	myGridBagConstraints.gridx=1;
   	myGridBagConstraints.gridy=0;
   	myGridBagConstraints.weightx=0;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=0;
	myGridBagConstraints.gridheight=2;
	myGridBagConstraints.insets=new Insets(20, 5, 10, 20);
   	myGridBagLayout.setConstraints(titleJLabel, myGridBagConstraints);
   
   	//userLabel
	myGridBagConstraints.fill=GridBagConstraints.BOTH;
   	myGridBagConstraints.insets=new Insets(5, 0, 5, 5);
   	myGridBagConstraints.gridx=0;
   	myGridBagConstraints.gridy=2;
   	myGridBagConstraints.weightx=0;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=1;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(userjLabel, myGridBagConstraints);
   	
   	//userTXT
   	myGridBagConstraints.gridx=1;
   	myGridBagConstraints.gridy=2;
   	myGridBagConstraints.weightx=1;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=0;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(userJTextField, myGridBagConstraints);
   	
   	//passLabel
   	myGridBagConstraints.gridx=0;
   	myGridBagConstraints.gridy=3;
   	myGridBagConstraints.weightx=0;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=1;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(passJLabel, myGridBagConstraints);
   	
   	//passTXT
   	myGridBagConstraints.gridx=1;
   	myGridBagConstraints.gridy=3;
   	myGridBagConstraints.weightx=1;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=0;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(passJTxtField, myGridBagConstraints);
   	
   	//registBT
   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
   	myGridBagConstraints.gridx=1;
   	myGridBagConstraints.gridy=4;
   	myGridBagConstraints.weightx=1;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=1;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(registJButton, myGridBagConstraints);
   	
   	//loginBT
   	myGridBagConstraints.gridx=2;
   	myGridBagConstraints.gridy=4;
   	myGridBagConstraints.weightx=1;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=1;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(loginJButton, myGridBagConstraints);
   	
   	//forgetBT
   	
   	myGridBagConstraints.gridx=3;
   	myGridBagConstraints.gridy=4;
   	myGridBagConstraints.weightx=1;
   	myGridBagConstraints.weighty=0;
   	myGridBagConstraints.gridwidth=1;
	myGridBagConstraints.gridheight=1;
   	myGridBagLayout.setConstraints(forgetJButton, myGridBagConstraints);
   	//loginJFrame.pack();
	loginJFrame.setVisible(true);
	
	loginJButton.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			// TODO Auto-generated method stub
			Connection conn=null;
			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			try {
				
				Class.forName("com.mysql.jdbc.Driver");//��������
				//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
			    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
			    String myName=userJTextField.getText();
			    String myPass=passJTxtField.getText();
			    
			    
			    String sql="select * from users where name=? and pass=?";
		        preparedStatement=conn.prepareStatement(sql);
		        preparedStatement.setString(1,myName);
		        preparedStatement.setString(2,myPass);
		      
		        resultSet=preparedStatement.executeQuery();
		        if(!resultSet.next()){
		        	JOptionPane.showMessageDialog(mainJPanel.getComponent(0), "�������");
		        }
		        else{
		        	JOptionPane.showMessageDialog(mainJPanel.getComponent(0), "��½�ɹ���");
		        	loginJFrame.setVisible(false);
		        	WriteDiary writeDiary=new WriteDiary(myName);
		        }
			    
			  
			    
				
				
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
				// TODO: handle exception
			}catch(SQLException e3) {
				e3.printStackTrace();
				// TODO: handle exception
			}finally {
				if(conn!=null){
					try {
						conn.close();
						//System.out.print("�رճɹ�");
					} catch (SQLException e2) {
						e2.printStackTrace();
						// TODO: handle exception
					}
					if(preparedStatement!=null){
						try {
							preparedStatement.close();
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
					}
				}
			}
			
		}
	});
	
	forgetJButton.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			Forget_user_Frame forget_user_Frame=new Forget_user_Frame();
			loginJFrame.setVisible(false);
			
		}
	});
	
    registJButton.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			loginJFrame.setVisible(false);
			RegistFrame registFrame=new RegistFrame();
		}	
	});
   	
       }
    
}
