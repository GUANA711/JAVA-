package guanling.zhao.diary;

import java.util.ArrayList;

import org.omg.CORBA.PUBLIC_MEMBER;

public class Time {
    private int hour;
    private int minute;
    private ArrayList<Integer> timeIntArry=new ArrayList<Integer>();
    
    public Time(String time){
    	char[] timeArry=new char[10];
    	timeArry=time.toCharArray();
    	int length=time.length();
    	int index=0;
    	while(length>0){
    		if(timeArry[index]>='0'&&timeArry[index]<='9')
    			timeIntArry.add((int)timeArry[index]-48);
    			length--;
    		    index++;
    	}
    	if(timeIntArry.size()!=4){
    		hour=1000;
    		minute=1000;
    		
    	}
    	else {
    		
        	
        	
        	for(int i=0;i<2;i++){
    			
    			hour=hour*10+timeIntArry.get(i);
    		}
    		for(int j=2;j<4;j++){
    			
    			minute=minute*10+timeIntArry.get(j);
    		}
		}
    	
    	
		
    		
		
    }
    
    public boolean timeJudege(){
    	if(hour<0||hour>24){
    		return false;
    	}
    	if(minute<0||minute>59){
    		return false;
    	}
    	
    	return true;
    }
    public String getTime(){
    	return hour+":"+minute;
    }
       
    
}
