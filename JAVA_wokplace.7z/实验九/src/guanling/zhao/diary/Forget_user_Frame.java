package guanling.zhao.diary;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Forget_user_Frame {
	private Font titleFont=new Font("����",Font.PLAIN,32);
	private Font userLabelFont=new Font("����",Font.PLAIN,20);
	private JFrame ForgetUserJFrame=new JFrame("Forget");
	private JLabel ForgetJLable=new JLabel("Forget");
	private JLabel userJLable=new JLabel("�û���");
	
//	private JLabel quesJLable=new JLabel("�ܱ�����");
//	private JLabel anwserJLable=new JLabel("�ܱ���");
//	private JLabel newPassJLable=new JLabel("�µ�����");
//	private JLabel rePassJLable=new JLabel("����ȷ��");
	private JTextField userTxtField=new JTextField();
	private JButton returnBT=new JButton("����");
	private JButton nextBT=new JButton("��һ��");
	
	public Forget_user_Frame(){
		init();
	}
	
	public  void init(){
		ForgetUserJFrame.setSize(500, 300);
		ForgetUserJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	   	int windowHight= ForgetUserJFrame.getHeight();
	   	int windowWith= ForgetUserJFrame.getWidth();
	   	Toolkit kit=Toolkit.getDefaultToolkit();
	   	int screenHight=kit.getScreenSize().height;
	   	int screenWith=kit.getScreenSize().width;
	   	ForgetUserJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);
	   	 
	   	GridBagLayout myGridBagLayout=new GridBagLayout();
	   	JPanel mainJPanel=new JPanel(myGridBagLayout);
	   	
	   	mainJPanel.add(ForgetJLable);
	   	mainJPanel.add(userJLable);
	   	mainJPanel.add(userTxtField);
	   	mainJPanel.add(nextBT);
	   	mainJPanel.add(returnBT);
	   	
	   	ForgetJLable.setFont(titleFont);
	   	userJLable.setFont(userLabelFont);
	   	
	   	ForgetUserJFrame.add(mainJPanel);
	   	
	   	GridBagConstraints myGridBagConstraints=new GridBagConstraints();
	   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
	   	
	   	//title
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=0;
	   	myGridBagConstraints.weightx=0;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagConstraints.gridwidth=0;
		myGridBagConstraints.gridheight=2;
		myGridBagConstraints.insets=new Insets(20, 30, 10, 30);
	   	myGridBagLayout.setConstraints(ForgetJLable, myGridBagConstraints);
	   	
	   	//username
		myGridBagConstraints.fill=GridBagConstraints.BOTH;
		myGridBagConstraints.insets=new Insets(5, 5, 5, 5);
	   	myGridBagConstraints.gridx=0;
	   	myGridBagConstraints.gridy=2;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=0;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(userJLable, myGridBagConstraints);
	   	
	   	//userTXT
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=2;
		myGridBagConstraints.gridwidth=0;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(userTxtField, myGridBagConstraints);
	   	
	   	//netBT
	   	myGridBagConstraints.insets=new Insets(25, 5, 5, 5);
	   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=3;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(nextBT, myGridBagConstraints);
	   	
	   	//returnBT
		
	   	myGridBagConstraints.gridx=2;
	   	myGridBagConstraints.gridy=3;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(returnBT, myGridBagConstraints);
	   	
	   	ForgetUserJFrame.setVisible(true);
	   	
	   	returnBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				LoginFrame loginFrame=new LoginFrame();
				ForgetUserJFrame.setVisible(false);
				
			}
		});
	   	
	   	nextBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Connection conn=null;
				PreparedStatement preparedStatement=null;
				ResultSet resultSet=null;
				try {
					
					Class.forName("com.mysql.jdbc.Driver");//��������
					//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
				    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
				    String myName=userTxtField.getText();
				   
				    
				    String sql="select question from users where name=? ";
			        preparedStatement=conn.prepareStatement(sql);
			        preparedStatement.setString(1,myName);
			       
			      
			        resultSet=preparedStatement.executeQuery();
			        if(!resultSet.next()){
			        	JOptionPane.showMessageDialog(mainJPanel.getComponent(0), "���û�������");
			        	userTxtField.setText("");
			        }
			        else{
			              ForgetUserJFrame.setVisible(false);	
			              //System.out.println(myName);
			              Forget_ques_Frame forget_ques_Frame=new Forget_ques_Frame(myName,resultSet.getString(1));
			        }
				    
				  
				    
					
					
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}catch(SQLException e3) {
					e3.printStackTrace();
					// TODO: handle exception
				}finally {
					if(conn!=null){
						try {
							conn.close();
							//System.out.print("�رճɹ�");
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
						if(preparedStatement!=null){
							try {
								preparedStatement.close();
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
						}
					}
				}
				
			}
			
		});
	   	
	   	
	   	
	}
}
