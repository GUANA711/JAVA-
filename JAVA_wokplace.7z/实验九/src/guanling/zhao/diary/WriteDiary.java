

/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��12��10�� ����4:51:30
 */
package guanling.zhao.diary;


import javax.swing.JPanel;
import com.eltima.components.ui.DatePicker;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.StyledEditorKit.BoldAction;
import javax.swing.text.html.HTMLDocument.HTMLReader.IsindexAction;

import org.omg.CORBA.PUBLIC_MEMBER;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.awt.print.Book;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class WriteDiary {
	  private ImageIcon imageIcon=new ImageIcon("����.png");
      private JFrame mainJFrame=new JFrame("�ռ� ϵͳ");
      private JLabel backGround=new JLabel(imageIcon);
      //����������
      private JLabel searchJLB=new JLabel("������ʽ");
      private JComboBox<String> searchJComBox=new JComboBox<String>();
      private JLabel searchContentJB=new JLabel("��������");
      private JTextField searchTxt=new JTextField();
      private JLabel dateBgLB=new JLabel("��ʼ����");
      private JLabel dateEdLB=new JLabel("��������");
      private JTextField dateBgTxt=new JTextField();
      private JTextField dateEdTxt=new JTextField();
      private JButton searchBT=new JButton("����");
      private JButton showAllBT=new JButton("��ʾ�����ռ�");
     
      private JList diaryList;
      private DefaultListModel<String> diaryModel=new DefaultListModel();
      private JButton addBt=new JButton("����");
      private JButton delBt=new JButton("ɾ��");
      private JButton empBt=new JButton("���");
      //�����Ҳ����
      private JLabel dateJLabel=new JLabel("����:");
      private JLabel moodLabel=new JLabel("����:");
      private JLabel titleJLabel=new JLabel("��Ŀ:");
      private JLabel weatherJLabel=new JLabel("����:");
      private JLabel contentJLabel=new JLabel("*����:");
      private DatePicker datepicker=getDatePicker();
      
      
      private JTextField dateTextField=new JTextField(10);
      private  JComboBox<String> moodJBox=new JComboBox<String>();
      //private JTextField moodTextField=new JTextField();
      private JTextField titleTextField=new JTextField();
      private JComboBox<String> weatherJBox=new JComboBox<String>();
     // private JTextField weatherTextField=new JTextField();
      private JTextArea  contentTextArea=new JTextArea();
      
      private JButton editBt=new JButton("�����ռ�");
      private JButton exitBT=new JButton("�˳���¼");
      private JButton cancelBt=new JButton("ȡ��");
      private JButton confirmBt=new JButton("ȷ��");
      private JButton uploadBT=new JButton("�ϴ�ͼƬ");
      
      private String userName;
      
     
    
      public WriteDiary(String userNname){
    	  this.userName=userNname;
    	  init();
      }
      private static DatePicker getDatePicker() {
          final DatePicker datepick;
          // ��ʽ
          String DefaultFormat = "yyyy-MM-dd";
          // ��ǰʱ��
          Date date = new Date();
          // ����
          Font font = new Font("Times New Roman", Font.BOLD, 14);
          Dimension dimension = new Dimension(177, 24);
          //���췽������ʼʱ�䣬ʱ����ʾ��ʽ�����壬�ؼ���С��
          datepick = new DatePicker(date, DefaultFormat, font, dimension);
          datepick.setLocation(137, 83);//������ʼλ��
         // ���ù���
          datepick.setLocale(Locale.CANADA);
          return datepick;
      }
  
      
  	public static void eventOnImport(JButton upload) {
		 ByteArrayOutputStream baos = null;
		 JFileChooser chooser = new JFileChooser();
		 chooser.setMultiSelectionEnabled(true);
		          
		 /** �����ļ����� * */
		 FileNameExtensionFilter filter = new FileNameExtensionFilter("��ѡ���ϴ�ͼƬ",
		   "jpg","png","jpeg","bmp");
		 chooser.setFileFilter(filter);
		 int returnVal = chooser.showOpenDialog(upload);
		 if (returnVal == JFileChooser.APPROVE_OPTION) {
		  /** �õ�ѡ����ļ�* */
		  File[] arrfiles = chooser.getSelectedFiles();
		  if (arrfiles == null || arrfiles.length == 0) {
		   return;
		  }
		  
		  FileInputStream input = null;
		  FileOutputStream out = null;
		  String path = "up";
		  try {
		   for (File f : arrfiles) {
		    File dir = new File(path);
		    dir.listFiles();
		    String fileNamnPath = path+f.getName();
		    new URL(fileNamnPath);
		    
		    input = new FileInputStream(f);
		    byte[] buffer = new byte[1024];
		    File des = new File(path, f.getName());
		    out = new FileOutputStream(des);
		    int len = 0;
		    baos = new ByteArrayOutputStream();
		    while (-1 != (len = input.read(buffer))) {
		    baos.write(buffer); 
		        out.write(buffer, 0, len);
		    }


		    ImageIcon IC = new ImageIcon(baos.toByteArray());
		IC.setImage(IC.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT));
		AbstractButton showPic = null;
		showPic.setIcon(IC);
		    
		    out.close();
		    input.close();
		   }
		   




		  } catch (FileNotFoundException e1) {
			  
		   JOptionPane.showMessageDialog(null, "�ϴ�ʧ�ܣ�", "��ʾ",
		     JOptionPane.ERROR_MESSAGE);
		   e1.printStackTrace();
		  } catch (IOException e1) {
		   JOptionPane.showMessageDialog(null, "�ϴ�ʧ�ܣ�", "��ʾ",
		     JOptionPane.ERROR_MESSAGE);
		   e1.printStackTrace();
		  }
		 }
		}
	
      public void init(){
    	  ImageIcon imageIcon = new ImageIcon("����.png"); // Icon��ͼƬ�ļ��γ�
    	  Image image = imageIcon.getImage(); // �����ͼƬ̫���ʺ���Icon
    	  
    	 //�������� 
    	  mainJFrame.setSize(800, 600);
    	  mainJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	  int windowHight=mainJFrame.getHeight();
    	  int windowWith=mainJFrame.getWidth();
    	  Toolkit kit=Toolkit.getDefaultToolkit();
    	  int screenHight=kit.getScreenSize().height;
    	  int screenWith=kit.getScreenSize().width;
    	  mainJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);//���ô��ھ�����ʾ
    	  //mainJFrame.setLocationRelativeTo(null);
    	  
    	  
    	  GridBagLayout gridBagLayout=new GridBagLayout();
    	  JPanel leftJPanel=new JPanel(gridBagLayout);
    	  JPanel rightJPanel=new JPanel(gridBagLayout);
          leftJPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
          rightJPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
    	  JSplitPane splitPane=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftJPanel, rightJPanel);
    	  splitPane.setResizeWeight(0.5);//ָ�������ÿؼ��Ĵ�С���൱�ڰٷֱ� 
    	  splitPane.setDividerLocation(0.4);
    	  //splitPane.setDividerSize(2);
    	  splitPane.setContinuousLayout(true);//���������ʾ
    	  //mainJFrame.setContentPane(splitPane);
    	 
    	  mainJFrame.add(splitPane);
    
    	 
    	  //��˳���������
    	  
    	  diaryList=new JList<>(diaryModel);
    	  diaryList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    	  ArrayList<String> moodArry=new ArrayList<String>();
    	  
    	  moodArry.add("����");
    	  moodArry.add("����");
    	  moodArry.add("ƽ��");
    	  moodArry.add("����");
    	  moodArry.add("����");
    	  moodJBox.addItem("����");
    	  moodJBox.addItem("����");
    	  moodJBox.addItem("ƽ��"); 
    	  moodJBox.addItem("����");
    	  moodJBox.addItem("����");
    	  ArrayList<String> weatherArry=new ArrayList<String>();
    	  weatherArry.add("��");
    	  weatherArry.add("����");
    	  weatherArry.add("С��");
    	  weatherArry.add("Сѩ");
    	  weatherArry.add("����");
    	  weatherArry.add("��ѩ");
    	  
    	  weatherJBox.addItem("��");
    	  weatherJBox.addItem("����");
    	  weatherJBox.addItem("С��");
    	  weatherJBox.addItem("Сѩ");
    	  weatherJBox.addItem("����");
    	  weatherJBox.addItem("��ѩ");
    	  
    	  searchJComBox.addItem("����");
    	  searchJComBox.addItem("����");
    	  searchJComBox.addItem("����");
    	  searchJComBox.addItem("�ռ����ݹؼ���");
    	  searchJComBox.addItem("���ڷ�Χ");
    	  
    	  
    	  
    	  leftJPanel.add(searchJLB);
    	  leftJPanel.add(searchJComBox);
    	  leftJPanel.add(searchContentJB);
    	  leftJPanel.add(dateBgLB);
    	  leftJPanel.add(dateBgTxt);
    	  leftJPanel.add(dateEdLB);
    	  leftJPanel.add(dateEdTxt);
    	  leftJPanel.add(searchTxt);
    	  leftJPanel.add(searchBT);
    	  leftJPanel.add(showAllBT);
    	  leftJPanel.add(diaryList);
    	  leftJPanel.add(addBt);
    	  leftJPanel.add(delBt);
    	  leftJPanel.add(empBt);
    	  
    	  
    	  rightJPanel.add(dateJLabel);
    	  rightJPanel.add(datepicker);
          rightJPanel.add(dateTextField);
          rightJPanel.add(moodLabel);
          rightJPanel.add(moodJBox);
          rightJPanel.add(titleJLabel);
          rightJPanel.add(titleTextField);
          rightJPanel.add(weatherJLabel);
          rightJPanel.add(weatherJBox);
         
          rightJPanel.add(contentJLabel);
          rightJPanel.add(contentTextArea);
          rightJPanel.add(uploadBT);
          rightJPanel.add(cancelBt);
          rightJPanel.add(confirmBt);
          rightJPanel.add(exitBT);
          
          editBt.setVisible(false);
          
          GridBagConstraints myGridBagConstraints= new GridBagConstraints();
          myGridBagConstraints.fill=GridBagConstraints.BOTH;  //��䷽ʽ��ˮƽ+��ֱ
          myGridBagConstraints.insets=new Insets(10, 10, 5, 10);
          //searchJLB
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.weightx=0;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(searchJLB, myGridBagConstraints);
          
          //searchJComBox
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth= GridBagConstraints.REMAINDER;
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(searchJComBox, myGridBagConstraints);
          
          //searchContentJB
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.weightx=0;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(searchContentJB, myGridBagConstraints);
          
          //searchTxt
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(searchTxt, myGridBagConstraints);
          
        //dateBgLB
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.weightx=0;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(dateBgLB, myGridBagConstraints);
          
          //dateBgTxt
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(dateBgTxt, myGridBagConstraints);
          
          //dateEdLB
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=2;
          myGridBagConstraints.weightx=0;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(dateEdLB, myGridBagConstraints);
          
          //dateEdTxt
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=2;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(dateEdTxt, myGridBagConstraints);
          
          
          //searchBT
          
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=3;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(searchBT, myGridBagConstraints);
          
          //showAllBt
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=4;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=0;
          gridBagLayout.setConstraints(showAllBT, myGridBagConstraints);
          
          //diarylist
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.gridwidth= GridBagConstraints.REMAINDER;
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=5;
          myGridBagConstraints.weightx=1;
          myGridBagConstraints.weighty=1;
          gridBagLayout.setConstraints(diaryList, myGridBagConstraints);
          
         
          //addbt
          myGridBagConstraints.insets=new Insets(30, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(addBt, myGridBagConstraints);
          
          //deleBt
          myGridBagConstraints.insets=new Insets(30, 10, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(delBt, myGridBagConstraints);
          
          //emptBT
          myGridBagConstraints.insets=new Insets(30, 10, 20, 10);
          myGridBagConstraints.gridx=2;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(empBt, myGridBagConstraints);
          
          //dateLabel
          myGridBagConstraints.insets=new Insets(10, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth = 1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(dateJLabel, myGridBagConstraints);
           
          //dateTextField
          myGridBagConstraints.insets=new Insets(10, 0, 20, 10);
          
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth =3;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(dateTextField, myGridBagConstraints);
          //datepicker
           myGridBagConstraints.insets=new Insets(10, 0, 20, 10);
          
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth =3;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(datepicker, myGridBagConstraints);
          
        //moodLabel
          myGridBagConstraints.gridx=4;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(moodLabel, myGridBagConstraints);
          
        //moodTextFiled
          myGridBagConstraints.gridx=5;
          myGridBagConstraints.gridy=0;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(moodJBox, myGridBagConstraints);
          
          //titleJLabel
          myGridBagConstraints.insets=new Insets(0, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(titleJLabel, myGridBagConstraints);
          
        //titleTextField
          myGridBagConstraints.insets=new Insets(0, 0, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=1;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(titleTextField, myGridBagConstraints);
          //weatherlb
          myGridBagConstraints.insets=new Insets(3, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=2;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(weatherJLabel, myGridBagConstraints);
          
          //weatherbt
          myGridBagConstraints.insets=new Insets(0, 0, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=2;
          myGridBagConstraints.gridwidth =0;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(weatherJBox, myGridBagConstraints);
          
         
       
    	 
        //tipLbel
          myGridBagConstraints.insets=new Insets(30, 10, 30, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=4;
          myGridBagConstraints.gridwidth=1;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(contentJLabel, myGridBagConstraints);
    	 
        //tipTxtArea
          myGridBagConstraints.insets = new Insets(0, 0, 0, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=4; 
          myGridBagConstraints.gridwidth=0;
          myGridBagConstraints.gridheight=2;
          myGridBagConstraints.weightx = 0;
          myGridBagConstraints.weighty = 1;
          gridBagLayout.setConstraints(contentTextArea, myGridBagConstraints);
          
          myGridBagConstraints.insets=new Insets(10, 10, 20, 10);
          myGridBagConstraints.gridx=0;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(uploadBT, myGridBagConstraints);
          //exiteBT
          myGridBagConstraints.insets=new Insets(10, 40, 20, 10);
          myGridBagConstraints.gridx=1;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(exitBT, myGridBagConstraints);
          
          //CANCELbt
          myGridBagConstraints.insets=new Insets(10, 40, 20, 10);
          myGridBagConstraints.gridx=7;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(cancelBt, myGridBagConstraints);
          
          //confirmBT
          myGridBagConstraints.insets=new Insets(10, 0, 20, 5);
          myGridBagConstraints.gridx=8;
          myGridBagConstraints.gridy=6;
          myGridBagConstraints.gridwidth =1;
          myGridBagConstraints.gridheight=1;
          myGridBagConstraints.weightx = 1;
          myGridBagConstraints.weighty = 0;
          gridBagLayout.setConstraints(confirmBt, myGridBagConstraints);
          
          //mainJFrame.pack();
          mainJFrame.setVisible(true);
          //�༭��Ĭ�ϲ��ܱ༭ 
        dateTextField.setEnabled(false);
      
      	titleTextField.setEnabled(false);
      	contentTextArea.setEnabled(false);
      	moodJBox.setEnabled(false);
      	weatherJBox.setEnabled(false);
      	dateBgLB.setVisible(false);
      	dateBgTxt.setVisible(false);
      	dateEdLB.setVisible(false);
      	dateEdTxt.setVisible(false);
      	datepicker.setVisible(false);
      	//datepicker.setEnabled(false);
      
        //listModel��ʼ��ȡ
      	 Connection conn=null;
			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			try {
				
				Class.forName("com.mysql.jdbc.Driver");//��������
				//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
			    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
			   
			           String myKey;
			           String sql="select userkey from diary where username=?";
				       preparedStatement=conn.prepareStatement(sql);
				       preparedStatement.setString(1,userName);
				       resultSet=preparedStatement.executeQuery();
				       while(resultSet.next()){
				    	   myKey=resultSet.getString(1);
				    	   diaryModel.addElement(myKey); 
				       }
				     
			  				   			
				
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
				// TODO: handle exception
			}catch(SQLException e3) {
				e3.printStackTrace();
				// TODO: handle exception
			}finally {
				if(conn!=null){
					try {
						conn.close();
						//System.out.print("�رճɹ�");
					} catch (SQLException e2) {
						e2.printStackTrace();
						// TODO: handle exception
					}
					if(preparedStatement!=null){
						try {
							preparedStatement.close();
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
					}
				}
			}
			uploadBT.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
					
				}
			});
      	  
			
          
          
          showAllBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				diaryModel.removeAllElements();
				Connection conn=null;
				PreparedStatement preparedStatement=null;
				ResultSet resultSet=null;
				try {
					
					Class.forName("com.mysql.jdbc.Driver");//��������
					//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
				    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
				   
				           String myKey;
				           String sql="select userkey from diary where username=?";
					       preparedStatement=conn.prepareStatement(sql);
					       preparedStatement.setString(1,userName);
					       resultSet=preparedStatement.executeQuery();
					       while(resultSet.next()){
					    	   myKey=resultSet.getString(1);
					    	   diaryModel.addElement(myKey); 
					       }
					     
				  				   			
					
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}catch(SQLException e3) {
					e3.printStackTrace();
					// TODO: handle exception
				}finally {
					if(conn!=null){
						try {
							conn.close();
							//System.out.print("�رճɹ�");
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
						if(preparedStatement!=null){
							try {
								preparedStatement.close();
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
						}
					}
				}
	      	
				
			}
		});
          
          //deleBT�¼�
          delBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(diaryList.isSelectionEmpty()){
					
					JOptionPane.showMessageDialog(leftJPanel.getComponent(0), "����ѡ��Ҫɾ�����г̣�");
				}
				if(diaryModel.isEmpty()){
					JOptionPane.showMessageDialog(leftJPanel.getComponent(0),"�б���Ϊ���ˣ�");
				}
				if(diaryList.getSelectedIndex()>=0){
		            int choice=JOptionPane.showConfirmDialog(leftJPanel, "ȷ��ɾ����");
		            if(choice==0){
		            	
		                Connection conn=null;
						PreparedStatement preparedStatement=null;
						ResultSet resultSet=null;
						try {
							
							Class.forName("com.mysql.jdbc.Driver");//��������
							//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
						    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
						   
						          
						           String sql="delete from diary where userkey=?";
							       preparedStatement=conn.prepareStatement(sql);
							       preparedStatement.setString(1,(String)diaryList.getSelectedValue());
							    
							       preparedStatement.executeUpdate();
							       diaryModel.remove(diaryList.getSelectedIndex());
					               dateTextField.setText("");
					            	
					            	titleTextField.setText("");
					            	
					                contentTextArea.setText("");	
						
						  				   			
							
						} catch (ClassNotFoundException e1) {
							e1.printStackTrace();
							// TODO: handle exception
						}catch(SQLException e3) {
							e3.printStackTrace();
							// TODO: handle exception
						}finally {
							if(conn!=null){
								try {
									conn.close();
									//System.out.print("�رճɹ�");
								} catch (SQLException e2) {
									e2.printStackTrace();
									// TODO: handle exception
								}
								if(preparedStatement!=null){
									try {
										preparedStatement.close();
									} catch (SQLException e2) {
										e2.printStackTrace();
										// TODO: handle exception
									}
								}
							}
						}}
					
				}
			}
		});
         //ȡ����ť 
          empBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(diaryModel.isEmpty()){
					JOptionPane.showMessageDialog(leftJPanel.getComponent(0),"�б���Ϊ���ˣ�");
				}
				else {
					int choice=JOptionPane.showConfirmDialog(leftJPanel, "ȷ��Ҫ����б���");
					 if(choice==0){
			            	diaryModel.clear();
			            	dateTextField.setText("");
			            	
			            	titleTextField.setText("");
			            	
			                contentTextArea.setText("");	
			                
			                Connection conn=null;
							PreparedStatement preparedStatement=null;
							ResultSet resultSet=null;
							try {
								
								Class.forName("com.mysql.jdbc.Driver");//��������
								//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
							    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
							   
							           String myKey=Judge.toString(dateTextField.getText(),titleTextField.getText());
							           String sql="delete from diary ";
								       preparedStatement=conn.prepareStatement(sql);   
								       preparedStatement.executeUpdate();
								       diaryModel.addElement(myKey);
							         
							} catch (ClassNotFoundException e1) {
								e1.printStackTrace();
								// TODO: handle exception
							}catch(SQLException e3) {
								e3.printStackTrace();
								// TODO: handle exception
							}finally {
								if(conn!=null){
									try {
										conn.close();
										//System.out.print("�رճɹ�");
									} catch (SQLException e2) {
										e2.printStackTrace();
										// TODO: handle exception
									}
									if(preparedStatement!=null){
										try {
											preparedStatement.close();
										} catch (SQLException e2) {
											e2.printStackTrace();
											// TODO: handle exception
										}
									}
								}
							}
			                }
						
					}
					
				}
				
			
		});
          //���Ӱ�ť
        addBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				   dateTextField.setEnabled(true);
		      	 
		      	   titleTextField.setEnabled(true);
		      		
		      	    contentTextArea.setEnabled(true);
			      	diaryList.setSelectedIndex(10);
			       	moodJBox.setEnabled(true);
			      	weatherJBox.setEnabled(true);
			      	dateTextField.setVisible(false);
			      	datepicker.setVisible(true);
			      datepicker.setEnabled(true);
			      	
			      
			      
				
			}
		});
        
        exitBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int choice=JOptionPane.showConfirmDialog(mainJFrame, "ȷ���˳���");
				if(choice==0){
					mainJFrame.setVisible(false);
					LoginFrame loginFrame=new LoginFrame();
				}
		
				
			}
		});
        
        
        confirmBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				boolean dateJudge=true;
				boolean moodJudge=true;
				boolean titleJudege=true;
				
				
				
		      	
		        if(contentTextArea.getText().equals("")){
		    		JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"���ݲ���Ϊ��");
		    		titleJudege=false;
		    	}
		        else{
		        	 Connection conn=null;
						PreparedStatement preparedStatement=null;
						ResultSet resultSet=null;
						try {
							
							Class.forName("com.mysql.jdbc.Driver");//��������
							//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
						    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
						   
						           String myKey=Judge.toString(datepicker.getText(),titleTextField.getText());
						           String sql="insert into diary values(?,?,?,?,?,?,?)";
							       preparedStatement=conn.prepareStatement(sql);
							       preparedStatement.setString(1,userName);
							       preparedStatement.setString(2,myKey);
							       preparedStatement.setString(3,datepicker.getText());
							       preparedStatement.setString(4,moodArry.get(moodJBox.getSelectedIndex()));
							       preparedStatement.setString(5,titleTextField.getText());
							       preparedStatement.setString(6,weatherArry.get(weatherJBox.getSelectedIndex()));
							       preparedStatement.setString(7,contentTextArea.getText());
							       preparedStatement.executeUpdate();

							       diaryModel.addElement(myKey);
							     
						    
						    
						    
						  
					       	    
						  				   			
							
						} catch (ClassNotFoundException e1) {
							e1.printStackTrace();
							// TODO: handle exception
						}catch(SQLException e3) {
							e3.printStackTrace();
							// TODO: handle exception
						}finally {
							if(conn!=null){
								try {
									conn.close();
									//System.out.print("�رճɹ�");
								} catch (SQLException e2) {
									e2.printStackTrace();
									// TODO: handle exception
								}
								if(preparedStatement!=null){
									try {
										preparedStatement.close();
									} catch (SQLException e2) {
										e2.printStackTrace();
										// TODO: handle exception
									}
								}
							}
						}
		        }
		        
		       
		        //����
		        
				    dateTextField.setEnabled(false);
			      
			      	titleTextField.setEnabled(false);
			      	contentTextArea.setEnabled(false);
			      	moodJBox.setEnabled(false);
			      	weatherJBox.setEnabled(false);
			        dateTextField.setVisible(true);
			      	datepicker.setVisible(false);
		      
			      	
				
				
			}
		});
        
     diaryList.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(!e.getValueIsAdjusting()){//�������if����õ������¼���Ϊʲô��
					String mykey=(String)diaryList.getSelectedValue();
					Connection conn=null;
					PreparedStatement preparedStatement=null;
					ResultSet resultSet=null;
					try {
						
						Class.forName("com.mysql.jdbc.Driver");//��������
						//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
					    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
					  			    
						String sql="select * from diary where userkey=?";
				        preparedStatement=conn.prepareStatement(sql);
				        preparedStatement.setString(1,mykey);
				        
                        resultSet=preparedStatement.executeQuery();
                        
                        while(resultSet.next()){
                        	
                        	dateTextField.setText(resultSet.getString(3));
                        	titleTextField.setText(resultSet.getString(5));
                        	contentTextArea.setText(resultSet.getString(7));
                        	moodJBox.setSelectedItem(resultSet.getString(4));
                        	weatherJBox.setSelectedItem(resultSet.getString(6));
                        	
                        }
				        
		   
												
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
						// TODO: handle exception
					}catch(SQLException e3) {
						e3.printStackTrace();
						// TODO: handle exception
					}finally {
						if(conn!=null){
							try {
								conn.close();
								//System.out.print("�رճɹ�");
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
							if(preparedStatement!=null){
								try {
									preparedStatement.close();
								} catch (SQLException e2) {
									e2.printStackTrace();
									// TODO: handle exception
								}
							}
						}
					}
			
					
			 
						
				
				
				}
			}
		});
        
        cancelBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dateTextField.setEnabled(false);
		      	titleTextField.setEnabled(false);
		      	
		      	contentTextArea.setEnabled(false);
		    	moodJBox.setEnabled(false);
		      	weatherJBox.setEnabled(false);
		      	datepicker.setEnabled(false);
		      	String key=(String)diaryList.getSelectedValue();
		      	dateTextField.setVisible(true);
			    datepicker.setVisible(false);
		      
				
			}
		});
        
        searchBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				diaryModel.removeAllElements();
				int jboxChoice=searchJComBox.getSelectedIndex();
				Connection conn=null;
				PreparedStatement preparedStatement=null;
				ResultSet resultSet=null;
				try {
					
					Class.forName("com.mysql.jdbc.Driver");//��������
					//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
				    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
				    if(jboxChoice==0){
				    	String sql="select userkey from diary where username=? and weather=?";
				        preparedStatement=conn.prepareStatement(sql);
				        preparedStatement.setString(1,userName);
				        preparedStatement.setString(2,searchTxt.getText());
				        resultSet=preparedStatement.executeQuery();
				        if(!resultSet.next())
				        {
				        	JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"û�з��ϵ��ռ�");
				        }
				        else {
				        	diaryModel.addElement(resultSet.getString(1));
				        	while(resultSet.next()){
				        		
				        		diaryModel.addElement(resultSet.getString(1));
				        	}
						}
				        
				     }
				    if(jboxChoice==1){
			        	String sql="select userkey from diary where username=? and title=?";
				        preparedStatement=conn.prepareStatement(sql);
				        preparedStatement.setString(1,userName);
				        preparedStatement.setString(2,searchTxt.getText());
				        resultSet=preparedStatement.executeQuery();
				        if(!resultSet.next())
				        {
				        	JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"û�з��ϵ��ռ�");
				        }
				        else {
				        	diaryModel.addElement(resultSet.getString(1));
				        	while(resultSet.next()){
				        		
				        		diaryModel.addElement(resultSet.getString(1));
				        	}
						}
			        }
			        
			         if(jboxChoice==2){
			        	String sql="select userkey from diary where username=? and mood=?";
				        preparedStatement=conn.prepareStatement(sql);
				        preparedStatement.setString(1,userName);
				        preparedStatement.setString(2,searchTxt.getText());
				        resultSet=preparedStatement.executeQuery();
				        if(!resultSet.next())
				        {
				        	JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"û�з��ϵ��ռ�");
				        }
				        else {
				        	diaryModel.addElement(resultSet.getString(1));
				        	while(resultSet.next()){
				        		
				        		diaryModel.addElement(resultSet.getString(1));
				        	}
				        }
			         } 
			         if(jboxChoice==3){
				        	String sql="select userkey from diary where username=? and contents like ?";
					        preparedStatement=conn.prepareStatement(sql);
					        preparedStatement.setString(1,userName);
					        preparedStatement.setString(2,'%'+searchTxt.getText()+'%');
					        resultSet=preparedStatement.executeQuery();
					        if(!resultSet.next())
					        {
					        	JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"û�з��ϵ��ռ�");
					        }
					        else {
					        	diaryModel.addElement(resultSet.getString(1));
					        	while(resultSet.next()){
					        		
					        		diaryModel.addElement(resultSet.getString(1));
					        	}
					        }
				         } 
			         if(jboxChoice==4){
			        	    
				        	String sql="select userkey from diary where username=? and date>=? and date<=?";
					        preparedStatement=conn.prepareStatement(sql);
					        preparedStatement.setString(1,userName);
					        preparedStatement.setString(2,dateBgTxt.getText());
					        preparedStatement.setString(3,dateEdTxt.getText());
					        resultSet=preparedStatement.executeQuery();
					        if(!resultSet.next())
					        {
					        	JOptionPane.showMessageDialog(rightJPanel.getComponent(0),"û�з��ϵ��ռ�");
					        }
					        else {
					        	diaryModel.addElement(resultSet.getString(1));
					        	while(resultSet.next()){
					        		
					        		diaryModel.addElement(resultSet.getString(1));
					        	}
					        }
				         } 
			         
				    
                    			
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}catch(SQLException e3) {
					e3.printStackTrace();
					// TODO: handle exception
				}finally {
					if(conn!=null){
						try {
							conn.close();
							//System.out.print("�رճɹ�");
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
						if(preparedStatement!=null){
							try {
								preparedStatement.close();
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
						}
					}
				}
				
				
			}
		});
        searchJComBox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(searchJComBox.getSelectedIndex()==4){
				    searchContentJB.setVisible(false);	
	        	    searchTxt.setVisible(false);
	        	    //searchContentJB.setVisible(false);
	        	    dateBgLB.setVisible(true);
	        	    dateBgTxt.setVisible(true);
	        	    dateEdLB.setVisible(true);
	        	    dateEdTxt.setVisible(true);
				}
				else{
					searchContentJB.setVisible(true);
	        	    searchTxt.setVisible(true);
	        	   // searchC.setVisible(true);
	        	    dateBgLB.setVisible(false);
	        	    dateBgTxt.setVisible(false);
	        	    dateEdLB.setVisible(false);
	        	    dateEdTxt.setVisible(false);
	        	   
				}
				
			}
		});
      
          
        
          
      }
     
     
      
    
}

