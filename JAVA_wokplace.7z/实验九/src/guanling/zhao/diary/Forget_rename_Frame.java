package guanling.zhao.diary;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Forget_rename_Frame {
	private Font titleFont=new Font("����",Font.PLAIN,32);
	private Font userLabelFont=new Font("����",Font.PLAIN,20);
    private JFrame forgetRenameJFrame=new JFrame("Reset Password");
    private JLabel titleJLabel=new JLabel("Reset Password");
    private JLabel newPassJLabel=new JLabel("�µ�����");
    private JLabel rePassJLabel=new JLabel("����ȷ��");
    private JTextField newPassJTxt=new JTextField();
    private JTextField rePassTxt=new JTextField();
    private JButton comfirmBT=new JButton("ȷ��");
    private JButton returnBT=new JButton("���ص�¼");
    private String myUserName;
    
    public Forget_rename_Frame(String userName){
    	this.myUserName=userName;
    	init();
    }
    
    public void init(){
    	forgetRenameJFrame.setSize(500, 300);
    	forgetRenameJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	   	int windowHight= forgetRenameJFrame.getHeight();
	   	int windowWith= forgetRenameJFrame.getWidth();
	   	Toolkit kit=Toolkit.getDefaultToolkit();
	   	int screenHight=kit.getScreenSize().height;
	   	int screenWith=kit.getScreenSize().width;
	   	forgetRenameJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);
	   	 
	   	GridBagLayout myGridBagLayout=new GridBagLayout();
	   	JPanel mainJPanel=new JPanel(myGridBagLayout);
	   	
	   	mainJPanel.add(titleJLabel);
	   	mainJPanel.add(newPassJLabel);
	   	mainJPanel.add(newPassJTxt);
	   	mainJPanel.add(rePassJLabel);
	   	mainJPanel.add(rePassTxt);
	   	mainJPanel.add(comfirmBT);
	   	mainJPanel.add(returnBT);
	   	
	   	titleJLabel.setFont(titleFont);
	   	newPassJLabel.setFont(userLabelFont);
	   	rePassJLabel.setFont(userLabelFont);
	   	
	   	forgetRenameJFrame.add(mainJPanel);
	   	
	   	GridBagConstraints myGridBagConstraints=new GridBagConstraints();
	   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
	   	
	    //title
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=0;
	   	myGridBagConstraints.weightx=0;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagConstraints.gridwidth=0;
		myGridBagConstraints.gridheight=2;
		myGridBagConstraints.insets=new Insets(20, 30, 10, 30);
	   	myGridBagLayout.setConstraints(titleJLabel, myGridBagConstraints);
	   	
	   	//newpassLB
		myGridBagConstraints.fill=GridBagConstraints.BOTH;
		myGridBagConstraints.insets=new Insets(5, 5, 5, 5);
	   	myGridBagConstraints.gridx=0;
	   	myGridBagConstraints.gridy=2;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=0;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(newPassJLabel, myGridBagConstraints);
	   	
	   	//newpassTXT
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=2;
		myGridBagConstraints.gridwidth=0;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(newPassJTxt, myGridBagConstraints);
	   	
	  //rePassJLabel
	  		myGridBagConstraints.fill=GridBagConstraints.BOTH;
	  		myGridBagConstraints.insets=new Insets(5, 5, 5, 5);
	  	   	myGridBagConstraints.gridx=0;
	  	   	myGridBagConstraints.gridy=3;
	  		myGridBagConstraints.gridwidth=1;
	  		myGridBagConstraints.gridheight=1;
	  	   	myGridBagConstraints.weightx=0;
	  	   	myGridBagConstraints.weighty=0;
	  	   	myGridBagLayout.setConstraints(rePassJLabel, myGridBagConstraints);
	  	   	
	  	   	//rePassTxt
	  	   	myGridBagConstraints.gridx=1;
	  	   	myGridBagConstraints.gridy=3;
	  		myGridBagConstraints.gridwidth=0;
	  		myGridBagConstraints.gridheight=1;
	  	   	myGridBagConstraints.weightx=1;
	  	   	myGridBagConstraints.weighty=0;
	  	   	myGridBagLayout.setConstraints(rePassTxt, myGridBagConstraints);  	
	   	
	   	
	   	
	   	
	   	//comfirmBT
	   	myGridBagConstraints.insets=new Insets(25, 5, 5, 5);
	   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=4;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(comfirmBT, myGridBagConstraints);
	   	//returBT
	 	myGridBagConstraints.gridx=2;
	   	myGridBagConstraints.gridy=4;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(returnBT, myGridBagConstraints);
	   	
	   	
	   	forgetRenameJFrame.setVisible(true);
	   	
	   	returnBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				forgetRenameJFrame.setVisible(false);
				LoginFrame loginFrame=new LoginFrame();
				
			}
		});
	   	
	   	comfirmBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Connection conn=null;
				PreparedStatement preparedStatement=null;
				
				String myPass=newPassJTxt.getText();
				String reMyPass=rePassTxt.getText();
				boolean isTrue=true;
				try {
					
					Class.forName("com.mysql.jdbc.Driver");//��������
					//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
				    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
				   
				    if(Judge.passwordJudge(myPass,reMyPass)==1){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�û�������������ĸ���ֺ��������");
				    	isTrue=false;
				    }
				    if(Judge.passwordJudge(myPass,reMyPass)==2){
	    	             JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�������Ϊ 8 λ������ܳ��� 30 λ");
	    	             isTrue=false;
	                 }
				    if(Judge.passwordJudge(myPass,reMyPass)==3){
	    	             JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�����������벻��ͬ");
	    	             isTrue=false;
	                 }
				   if(isTrue){
					    String sql="update users set pass=? where name=?";
				        preparedStatement=conn.prepareStatement(sql);
				        preparedStatement.setString(2,myUserName);
				        preparedStatement.setString(1,myPass);
				        preparedStatement.executeUpdate();
				        JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�޸ĳɹ���");
				        forgetRenameJFrame.setVisible(false);
				        LoginFrame loginFrame=new LoginFrame();
				   }
				    
				  
			       
			        	
			        
			        
				    
				  
				    
					
					
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}catch(SQLException e3) {
					e3.printStackTrace();
					// TODO: handle exception
				}finally {
					if(conn!=null){
						try {
							conn.close();
							//System.out.print("�رճɹ�");
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
						if(preparedStatement!=null){
							try {
								preparedStatement.close();
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
						}
					}
				}
			}
		});
	   	
    }
}
