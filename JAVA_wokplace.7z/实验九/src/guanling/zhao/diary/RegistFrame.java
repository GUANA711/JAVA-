package guanling.zhao.diary;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class RegistFrame {
	private Font titleFont=new Font("����",Font.PLAIN,32);
	private Font userLabelFont=new Font("����",Font.PLAIN,20);
	private JFrame registJFrame=new JFrame("Regist");
	private JLabel titleJLabel=new JLabel("Regists");
	private JLabel userjLabel=new JLabel("�û���");
	private JLabel passJLabel=new JLabel("��  ��");
	private JLabel rePassJLabel=new JLabel("����ȷ��");
	private JLabel questionJLabel=new JLabel("�ܱ�����");
	private JLabel answerJLabel=new JLabel("�ܱ���");
	private JLabel securityJLabel=new JLabel("��֤��");
	private JLabel secuAnswerJLabel=new JLabel("��֤���");
	private JLabel mailJLabel=new JLabel("�� ��");
	private JLabel secuContentJLabel=new JLabel();
    private JTextField userJTextField=new JTextField();
    private JTextField passJTxtField=new JTextField();
    private JTextField rePassJTxtField=new JTextField();
    private JTextField mailJTxtField=new JTextField();
    private JComboBox<String> questionJComboc=new JComboBox<String>();
    private JTextField secuAnwserJTextField=new JTextField();
    private JTextField anwserJTxtField=new JTextField();
    
    private JButton registJButton=new JButton("ע��");
    private JButton returnJButton=new JButton("����");
    
    public RegistFrame(){
    	init();
    }
    
    public void init(){
    	 registJFrame.setSize(500, 600);
    	 registJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
     	  int windowHight=  registJFrame.getHeight();
     	  int windowWith=  registJFrame.getWidth();
     	  Toolkit kit=Toolkit.getDefaultToolkit();
     	  int screenHight=kit.getScreenSize().height;
     	  int screenWith=kit.getScreenSize().width;
     	 registJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);
     	 
     	 GridBagLayout myGridBagLayout=new GridBagLayout();
     	 JPanel mainJPanel=new JPanel(myGridBagLayout);
     	 
     	 questionJComboc.addItem("�������");
     	 questionJComboc.addItem("��ĵ绰����");
     	 questionJComboc.addItem("��ϲ������ɫ��");
     	 
     	 titleJLabel.setFont(titleFont);
     	 userjLabel.setFont(userLabelFont);
     	 passJLabel.setFont(userLabelFont);
     	 questionJLabel.setFont(userLabelFont);
     	 answerJLabel.setFont(userLabelFont);
     	 securityJLabel.setFont(userLabelFont);
     	 secuAnswerJLabel.setFont(userLabelFont);
     	 mailJLabel.setFont(userLabelFont);
     	 rePassJLabel.setFont(userLabelFont);
     	 secuContentJLabel.setFont(userLabelFont);
     	 
       	 mainJPanel.add(titleJLabel);
     	 mainJPanel.add(userjLabel);
     	 mainJPanel.add(userJTextField);
     	 mainJPanel.add(passJLabel);
     	 mainJPanel.add(passJTxtField);
     	 mainJPanel.add(rePassJLabel);
     	 mainJPanel.add(rePassJTxtField);
     	 mainJPanel.add(mailJLabel);
     	 mainJPanel.add(mailJTxtField);
     	 mainJPanel.add(questionJLabel);
     	 mainJPanel.add(questionJComboc);
     	 mainJPanel.add(answerJLabel);
     	 mainJPanel.add(anwserJTxtField);
     	 mainJPanel.add(securityJLabel);
     	 mainJPanel.add(secuContentJLabel);
     	 mainJPanel.add(secuAnswerJLabel);
     	 mainJPanel.add(secuAnwserJTextField);
     	 mainJPanel.add(registJButton);
         mainJPanel.add(returnJButton);	
     	 
     	 registJFrame.add(mainJPanel);
     	 //registJFrame.setVisible(true);
     	 
     	//loginJFrame.setVisible(true);
        GridBagConstraints myGridBagConstraints= new GridBagConstraints();
        myGridBagConstraints.fill=GridBagConstraints.CENTER;
        
       
		
        	
        //title
        myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=0;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=2;
        myGridBagConstraints.weightx=0;
        myGridBagConstraints.weighty=0;
        myGridBagConstraints.insets=new Insets(20, 5, 10, 20);
        myGridBagLayout.setConstraints(titleJLabel, myGridBagConstraints);
        
        //username
        myGridBagConstraints.fill=GridBagConstraints.BOTH;
        
        myGridBagConstraints.gridx=0;
        myGridBagConstraints.gridy=2;
        myGridBagConstraints.gridwidth=1;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=0;
        myGridBagConstraints.weighty=0;
        myGridBagConstraints.insets=new Insets(20, 5, 10, 20);
        myGridBagLayout.setConstraints(userjLabel, myGridBagConstraints);
        
        //userTXT
        myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=2;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(userJTextField, myGridBagConstraints);
        
      //passLabel
       	myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=3;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(passJLabel, myGridBagConstraints);
       	
       	//passTXT
       	myGridBagConstraints.gridx=1;
       	myGridBagConstraints.gridy=3;
       	myGridBagConstraints.weightx=1;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=0;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(passJTxtField, myGridBagConstraints);
       	
       	//repassLabel
       	myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=4;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(rePassJLabel, myGridBagConstraints);
       	
       	//repassTXT
       	
       	myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=4;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(rePassJTxtField, myGridBagConstraints);
        
       	//maileLabel
       	myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=5;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(mailJLabel, myGridBagConstraints);
       	
       	//maileTXT
        myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=5;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(mailJTxtField, myGridBagConstraints);
        
        //quesLable
        
    	myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=6;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(questionJLabel, myGridBagConstraints);
       	
       	//quesJBox
       	myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=6;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(questionJComboc, myGridBagConstraints);
        
        //anwserLable
        
        myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=7;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(answerJLabel, myGridBagConstraints);
       	
       	//anwserTXT
       	
    	myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=7;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(anwserJTxtField, myGridBagConstraints);
        
        //secuLable
        myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=8;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(securityJLabel, myGridBagConstraints);
       	
       	//secuTXT
       	myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=8;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(secuContentJLabel, myGridBagConstraints);
        
        //secuanserLabel
        myGridBagConstraints.gridx=0;
       	myGridBagConstraints.gridy=9;
       	myGridBagConstraints.weightx=0;
       	myGridBagConstraints.weighty=0;
       	myGridBagConstraints.gridwidth=1;
    	myGridBagConstraints.gridheight=1;
       	myGridBagLayout.setConstraints(secuAnswerJLabel, myGridBagConstraints);
       	
       	//secuanserTXT
    	myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=9;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(secuAnwserJTextField, myGridBagConstraints);
        
        //regist
        myGridBagConstraints.insets=new Insets(20, 5, 30, 20);
        myGridBagConstraints.fill=GridBagConstraints.CENTER;
        myGridBagConstraints.gridx=1;
        myGridBagConstraints.gridy=10;
        myGridBagConstraints.gridwidth=1;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(registJButton, myGridBagConstraints);
        
        //rerurn
        
        myGridBagConstraints.gridx=2;
        myGridBagConstraints.gridy=10;
        myGridBagConstraints.gridwidth=0;
     	myGridBagConstraints.gridheight=1;
        myGridBagConstraints.weightx=1;
        myGridBagConstraints.weighty=0;
        myGridBagLayout.setConstraints(returnJButton, myGridBagConstraints);
        
        registJFrame.setVisible(true);
        
      //���������֤��
        int num1,num2,num3;
        //int anwser;
        num1=new Random().nextInt(10);
		num2=new Random().nextInt(10);
		num3=new Random().nextInt(10);
		secuContentJLabel.setText(num1+"*"+num2+"-"+num3);
		
		returnJButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stubn
				LoginFrame loginFrame=new LoginFrame();
				registJFrame.setVisible(false);
				
			}
		});
        
        registJButton.addActionListener(new ActionListener(
        		) {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				boolean isTrue=true;
				Connection conn=null;
				PreparedStatement preparedStatement=null;
				ResultSet resultSet=null;
				try {
					
					Class.forName("com.mysql.jdbc.Driver");//��������
					//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
				    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
				    String myName=userJTextField.getText();
				    String myPass=passJTxtField.getText();
				    String reMyPass=rePassJTxtField.getText();
				    //username�ж�
				    if(Judge.userNameJudge(myName)==1){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�û�����̲������� 6 ���ַ������ �ܳ��� 20 ���ַ�");
				    	isTrue=false;
				    }
				    else if(Judge.userNameJudge(myName)==2){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�û�������ĸֻ��Ϊ��ĸ");
				    	isTrue=false;
				    }
				    else if(Judge.userNameJudge(myName)==3){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�û���ֻ�ܰ�����ĸ�����ֺ��»���");
				    	isTrue=false;
				    }
				    
				    //password�ж�
				    if(Judge.passwordJudge(myPass,reMyPass)==1){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�û�������������ĸ���ֺ��������");
				    	isTrue=false;
				    }
				    if(Judge.passwordJudge(myPass,reMyPass)==2){
	    	             JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�������Ϊ 8 λ������ܳ��� 30 λ");
	    	             isTrue=false;
	                 }
				    if(Judge.passwordJudge(myPass,reMyPass)==3){
	    	             JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�����������벻��ͬ");
	    	             isTrue=false;
	                 }
				    //mail�ж�
				    if(!Judge.mailJudge(mailJTxtField.getText())){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�����ʽ����");
				    	isTrue=false;
				    }
				    
				    if(anwserJTxtField.getText().equals("")){
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"�ܱ��𰸲���Ϊ�գ�");
				    	isTrue=false;
				    	
				    }
				    if(!secuAnwserJTextField.getText().equals("")){
				    	
				    	int anwser=0;
				    	boolean isFushu=false;
				    	char[] secuAnwserArry=secuAnwserJTextField.getText().toCharArray();
				    	//secuAnwserJTextField.getText()
				    	
				    	if(secuAnwserArry[0]=='-') isFushu=true;
				    	
				    	if(isFushu){
                               for(int i=1;i<secuAnwserArry.length;i++){
						    	
					    		anwser=anwser*10+(int)(secuAnwserArry[i]-'0');
					    	}
                               anwser=0-anwser;
				    	}
				    	else {
				    		for(int i=0;i<secuAnwserArry.length;i++){
						    	
					    		anwser=anwser*10+(int)(secuAnwserArry[i]-'0');
					    	}
						}
				    	
					    
					    if(anwser!=(num1*num2-num3)){
					    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"��֤�����");
					    	isTrue=false;
					    }
				    }
				    else {
				    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"��������֤��Ϣ��");
				    	isTrue=false;
					}
				    
				    //�������ݿ�
				    if(isTrue){
				    	    String sql="insert into users values(?,?,?,?,?)";
					        preparedStatement=conn.prepareStatement(sql);
					        preparedStatement.setString(1,myName);
					        preparedStatement.setString(2,myPass);
					        preparedStatement.setString(3,mailJTxtField.getText());
					        preparedStatement.setString(4,(String) questionJComboc.getSelectedItem());
					        preparedStatement.setString(5,anwserJTxtField.getText());
					        preparedStatement.executeUpdate();
					        JOptionPane.showMessageDialog(mainJPanel.getComponent(0),"ע��ɹ���");
					        
					        userJTextField.setText("");
					        passJTxtField.setText("");
					        rePassJTxtField.setText("");
					        mailJTxtField.setText("");
					        secuAnwserJTextField.setText("");
					        anwserJTxtField.setText("");
					        
					        registJFrame.setVisible(false);
					        LoginFrame loginFrame=new LoginFrame();
					        
					        
					      
					       
				    }
				  
				    
					
					
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}catch(SQLException e3) {
					e3.printStackTrace();
					// TODO: handle exception
				}finally {
					if(conn!=null){
						try {
							conn.close();
							//System.out.print("�رճɹ�");
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
						if(preparedStatement!=null){
							try {
								preparedStatement.close();
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
						}
					}
				}
				
				
			
				
			}
		});
        
        
    }
}
