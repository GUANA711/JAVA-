/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��12��20�� ����4:51:30
 */
package guanling.zhao.diary;

public class Test {
	public static void main(String[] args) {
		LoginFrame myLoginFrame=new LoginFrame();
		//RegistFrame test=new RegistFrame();
		//Forget_user_Frame test=new Forget_user_Frame();
	    //Forget_ques_Frame forget_ques_Frame=new Forget_ques_Frame("zhao_520","123456");	
		//Forget_rename_Frame forget_rename_Frame=new Forget_rename_Frame("zhao_520");
		
	}
  
}
