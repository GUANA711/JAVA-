package guanling.zhao.diary;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
public class Forget_ques_Frame {
	private Font titleFont=new Font("����",Font.PLAIN,32);
	private Font userLabelFont=new Font("����",Font.PLAIN,20);
	private JFrame forgetQueJFrame=new JFrame("SecretQuestion");
	private JLabel secretQueJLable=new JLabel("SecretQuestion");
    private JLabel quesJLable=new JLabel("�ܱ�����");
    private JLabel quesContentJLable=new JLabel();
    private JLabel anwserJLable=new JLabel("�ܱ���");
    private JTextField anwserJTxt=new JTextField();
    private JButton returnBT=new JButton("���ص�¼");
	private JButton nextBT=new JButton("��һ��");
	
	private String myUserName;
	private String mySecret;
	
	public Forget_ques_Frame(String userName,String secret){
		this.myUserName=userName;
		this.mySecret=secret;
		init();
	}
	
	public void init(){
		forgetQueJFrame.setSize(500, 300);
		forgetQueJFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	   	int windowHight= forgetQueJFrame.getHeight();
	   	int windowWith= forgetQueJFrame.getWidth();
	   	Toolkit kit=Toolkit.getDefaultToolkit();
	   	int screenHight=kit.getScreenSize().height;
	   	int screenWith=kit.getScreenSize().width;
	   	forgetQueJFrame.setLocation(screenWith/2-windowWith/2, screenHight/2-windowHight/2);
	   	 
	   	GridBagLayout myGridBagLayout=new GridBagLayout();
	   	JPanel mainJPanel=new JPanel(myGridBagLayout);
	   	
	   	mainJPanel.add(secretQueJLable);
	   	mainJPanel.add(quesJLable);
	   	mainJPanel.add(quesContentJLable);
	   	mainJPanel.add(anwserJLable);
	   	mainJPanel.add(anwserJTxt);
	   	mainJPanel.add(nextBT);
	   	mainJPanel.add(returnBT);
	   	
	   	secretQueJLable.setFont(titleFont);
	   	quesJLable.setFont(userLabelFont);
	   	quesContentJLable.setFont(userLabelFont);
	   	anwserJLable.setFont(userLabelFont);
	   	
	   	forgetQueJFrame.add(mainJPanel);
	   	
	   	GridBagConstraints myGridBagConstraints=new GridBagConstraints();
	   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
	   	
	  //title
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=0;
	   	myGridBagConstraints.weightx=0;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagConstraints.gridwidth=0;
		myGridBagConstraints.gridheight=2;
		myGridBagConstraints.insets=new Insets(20, 30, 10, 30);
	   	myGridBagLayout.setConstraints(secretQueJLable, myGridBagConstraints);
	   	
	   	//quesJLable
		myGridBagConstraints.fill=GridBagConstraints.BOTH;
		myGridBagConstraints.insets=new Insets(5, 5, 5, 5);
	   	myGridBagConstraints.gridx=0;
	   	myGridBagConstraints.gridy=2;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=0;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(quesJLable, myGridBagConstraints);
	   	
	   	//quesContentJLable
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=2;
		myGridBagConstraints.gridwidth=0;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(quesContentJLable, myGridBagConstraints);
	   	
	  //anwserlb
	  		myGridBagConstraints.fill=GridBagConstraints.BOTH;
	  		myGridBagConstraints.insets=new Insets(5, 5, 5, 5);
	  	   	myGridBagConstraints.gridx=0;
	  	   	myGridBagConstraints.gridy=3;
	  		myGridBagConstraints.gridwidth=1;
	  		myGridBagConstraints.gridheight=1;
	  	   	myGridBagConstraints.weightx=0;
	  	   	myGridBagConstraints.weighty=0;
	  	   	myGridBagLayout.setConstraints(anwserJLable, myGridBagConstraints);
	  	   	
	  	   	//anwserJTxt
	  	   	myGridBagConstraints.gridx=1;
	  	   	myGridBagConstraints.gridy=3;
	  		myGridBagConstraints.gridwidth=0;
	  		myGridBagConstraints.gridheight=1;
	  	   	myGridBagConstraints.weightx=1;
	  	   	myGridBagConstraints.weighty=0;
	  	   	myGridBagLayout.setConstraints(anwserJTxt, myGridBagConstraints);  	
	   	
	   	
	   	
	   	
	   	//netBT
	   	myGridBagConstraints.insets=new Insets(25, 5, 5, 5);
	   	myGridBagConstraints.fill=GridBagConstraints.CENTER;
	   	myGridBagConstraints.gridx=1;
	   	myGridBagConstraints.gridy=4;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(nextBT, myGridBagConstraints);
	   	
	   	//returnBT
		
	   	myGridBagConstraints.gridx=2;
	   	myGridBagConstraints.gridy=4;
		myGridBagConstraints.gridwidth=1;
		myGridBagConstraints.gridheight=1;
	   	myGridBagConstraints.weightx=1;
	   	myGridBagConstraints.weighty=0;
	   	myGridBagLayout.setConstraints(returnBT, myGridBagConstraints);
	   	
	    quesContentJLable.setText(this.mySecret);
	   	forgetQueJFrame.setVisible(true);
	   	
	   	returnBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				forgetQueJFrame.setVisible(false);
			    LoginFrame loginFrame=new LoginFrame();	
				
			}
		});
	   	
	   	nextBT.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Connection conn=null;
				PreparedStatement preparedStatement=null;
				ResultSet resultSet=null;
				try {
					
					Class.forName("com.mysql.jdbc.Driver");//��������
					//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
				    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
				   
				    String anwser=anwserJTxt.getText();
				   
				    
				    String sql="select anwser from users where name=? ";
			        preparedStatement=conn.prepareStatement(sql);
			        preparedStatement.setString(1,myUserName);
			        resultSet=preparedStatement.executeQuery();
			        while(resultSet.next()){
			        	
			        	anwser=resultSet.getString(1);
			       	    //System.out.println(anwser);
			       	    if(!anwserJTxt.getText().equals(anwser)){
			       	    	JOptionPane.showMessageDialog(mainJPanel.getComponent(0), "�ش����");
				            anwserJTxt.setText(" ");	
			       	    }
			       	    else {
							forgetQueJFrame.setVisible(false);
							Forget_rename_Frame forget_rename_Frame=new Forget_rename_Frame(myUserName);
						}
			        	
			        	
			        }
			        
			        
				    
				  
				    
					
					
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}catch(SQLException e3) {
					e3.printStackTrace();
					// TODO: handle exception
				}finally {
					if(conn!=null){
						try {
							conn.close();
							//System.out.print("�رճɹ�");
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
						if(preparedStatement!=null){
							try {
								preparedStatement.close();
							} catch (SQLException e2) {
								e2.printStackTrace();
								// TODO: handle exception
							}
						}
					}
				}
				
				
			}
		});
	   	
	   	
	}
   
}
