package guanling.zhao.number;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;



public class FrequencyCalculator extends Exception{
    private Map<Integer, Integer> numbers=new HashMap<>(); 
    
	public void  add(int num){
	   int oldValue;
	   if(numbers.containsKey(num)){
		   oldValue=numbers.get(num);
		   numbers.put(num, oldValue+1);
	   }
	   else{
		   numbers.put(num, 1);
	   }
	}
	
	public void add(int [] nums){
	    int oldValue;
	    for(int num:nums){
	    	if(numbers.containsKey(num)){
	 		   oldValue=numbers.get(num);
	 		   numbers.put(num, oldValue+1);
	 	   }
	 	   else{
	 		   numbers.put(num, 1);
	 	   }
	    }
	}
	
    
	
     List<Map<Integer, Integer>> getHighest() throws  NoNumberException{
		if(numbers.size()==0){
			throw new  NoNumberException("û�����ֿ�����");
		}
    	 
    	 
    	 List<Map<Integer, Integer>> highest=new ArrayList<Map<Integer,Integer>>();
    	 TreeSet<Integer> valueCount=new TreeSet<Integer>();
    	 
    	 
    	 for(int value:numbers.values()){
    		 valueCount.add(value);
    		 
    	 }
    	 int count=valueCount.size();//��¼�ж��ٸ�map���飬���������ֵ�Ƶ���м���
    	//��¼ǰ��������
    	 int index=1;
    	 int[] finalValueCount=new int[count];
    	 int freCount=count-1;
    		 for(int numCount:valueCount){
    			 finalValueCount[ freCount]=numCount;
    			 freCount--;
    		 }
    		 
    	     	// Map<Integer, Integer>[] highMapArry=new Map[count];
    	 for(int j=0;j<count;j++){
    		 Map<Integer, Integer> highMapArry=new HashMap<>();
    		 for(int key:numbers.keySet()){
    			 int value=numbers.get(key);
    			 if(finalValueCount[j]==value){
    				 highMapArry.put(key, finalValueCount[j]);
    				 
    			 }
    		 }
    		 if(index<=3){
    			 highest.add(highMapArry);
    		 }
    		 index++;
    	 }
    	
    	 //System.out.println(highest[0].);
    	
    	
    	
    	return highest;
    }
     
    List<Map<Integer, Integer>> getLowest() throws  NoNumberException{
    	
    	if(numbers.size()==0){
			throw new  NoNumberException("û�����ֿ�����");
		}
    	 List<Map<Integer, Integer>> lowest=new ArrayList<Map<Integer,Integer>>();
    	 TreeSet<Integer> valueCount=new TreeSet<Integer>();
    	
    	 for(int value:numbers.values()){
    		 valueCount.add(value);
    		 
    	 }
    	 int count=valueCount.size();//��¼�ж��ٸ�map���飬���������ֵ�Ƶ���м���
    	 int index=1;//��¼ǰ��������
    	// Map<Integer, Integer>[] highMapArry=new Map[count];
    	 for(int numCount:valueCount){
    		 Map<Integer, Integer> lowMapArry=new HashMap<>();
    		 for(int key:numbers.keySet()){
    			 int value=numbers.get(key);
    			 if(numCount==value){
    				 lowMapArry.put(key, numCount);
    				 
    			 }
    		 }
    		 if(index<=3){
    			 lowest.add(lowMapArry);
    		 }
    		 index++;
    	 }
    	
    	 //System.out.println(highest[0].);
    	
    	
    	
    	return lowest;
    }
    
    void clear(){
    	numbers.clear();
    }
    	
     
	 
}
