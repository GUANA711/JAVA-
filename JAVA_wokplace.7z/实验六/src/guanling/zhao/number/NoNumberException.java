package guanling.zhao.number;

import javax.xml.ws.handler.MessageContext;

public class NoNumberException extends Exception {

  public  NoNumberException(String msg){
	  super(msg);
  }
	
	

}
