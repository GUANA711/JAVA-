package guanling.zhao.menu;

import java.time.Year;

import guanling.zhao.menu.mood;
import guanling.zhao.menu.weather;

enum weather{sun,cloudy,rain,snow};
enum mood{happy,sad,normal}
public class Diary implements Comparable {
	private Date day;
	private String title;
	private String contents;
	private weather weather;
	private mood mood;
	
    public Diary(Date day,String title,String contents,weather weather,mood mood){ 
    	this.day=day;
    	this.title=title;
    	this.contents=contents;
    	this.weather=weather;
    	this.mood=mood;
    }
    
     public String toString(){
    	return day.getDate()+" "+weather+" "+mood+" "+title+" "+contents;
    }
     
     public String getTitle(){
    	 return title;
     }
     
     public Date getDate(){
    	 return this.day;
     }
     
     public String getContens(){
    	 return contents;
     }

	@Override
	public int compareTo(Object otherDiary) {
		Diary myDiary=(Diary)otherDiary;
	
	    if(day.getYear()==myDiary.getDate().getYear()){
	    	if(day.getMonth()==myDiary.getDate().getMonth()){
	    		return day.getdday()-myDiary.getDate().getdday();
	    	}
	    	else {
				return day.getMonth()-myDiary.getDate().getMonth();
			}
	    }
	    else {
			return day.getYear()-myDiary.getDate().getYear();
		}
		
		
		
	}
     
     
	

}
