/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��10��16�� ����13:24:22
 */
package guanling.zhao.menu;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

public class Test {
    public static void main(String[] args) {
    	Scanner input=new Scanner(System.in);
    	ArrayList<String> firstMenuContents=new ArrayList<String>();
    	firstMenuContents.add("��¼ϵͳ");
    	firstMenuContents.add("ϵͳ����");
    	firstMenuContents.add("д�ռ�");
    	firstMenuContents.add("�����ռ�");
    	firstMenuContents.add("�˳�ϵͳ");
    	
    	ArrayList<String> secondMenuContents=new ArrayList<String>();
    	secondMenuContents.add("�鿴�ռ��б� ");
    	secondMenuContents.add("������һ��˵� ");
    	
    	
    	Menu firstMenu=new Menu(firstMenuContents);
    	Menu secondMenu=new Menu(secondMenuContents);
    	Date firsrDate=new Date("2019/01/01");
    	Diary firstDiary=new Diary(firsrDate,"First" ,"This is my first diary", weather.snow, mood.happy);
    	Date secondDate=new Date("2019/01/02");
    	Diary secondDiary=new Diary(secondDate,"Second" ,"This is my second diary", weather.sun, mood.happy);
    	Date thirdDate=new Date("2019/01/03");
    	Diary thirdDiary=new Diary(thirdDate,"Second" ,"This is my third diary", weather.sun, mood.normal);
    
    	TreeSet<Diary> daTreeSet=new TreeSet<Diary>();
    	daTreeSet.add(thirdDiary);
    	daTreeSet.add(secondDiary);
    	daTreeSet.add(firstDiary);
    	
    	
    	boolean exit=false;
    	do {
			firstMenu.munePrint();
			int mainChoice;
			mainChoice=input.nextInt();
			switch (mainChoice) {
			case 1:
				
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
		        secondMenu.munePrint();
		        int secondchoice=input.nextInt();
		        switch (secondchoice) {
				case 1:
					int count=1;
					for(Diary diary:daTreeSet){
						System.out.println(count+":"+diary.getTitle()+"  "+diary.getDate().getDate());
						count++;
					}
					System.out.println("��ѡ���ռǣ�");
					int thirdChoice=input.nextInt();
					if(thirdChoice<0||thirdChoice>daTreeSet.size()){
						System.out.println("�������");
					}
					else {
						int diaryCount=1;
						for(Diary diary:daTreeSet){
							if(diaryCount==thirdChoice){
								System.out.println(diary.getContens());
								
							}
							diaryCount++;
						}
					}
					
					//System.out.println("1");
					break;
				case 2:
					break;

				default:
					System.out.println("�������������ѡ��");
					break;
				}
		        //System.out.println("1");
				break;
			case 5:
				exit=true;
				break;
			default:
				System.out.println("�������������ѡ��");
				break;
			}
		} while (!exit);
    	
    	
		
		
	}
}
