/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(用一句话描述该文件做什么) 

 * 

 * @author          赵官凌

 * @version         V1.0  

 * @Date           2019年12月7日 下午13:21:30
 */
package guanling.zhao.choice_corse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
	 public static void main(String[] args) {
		    Scanner input=new Scanner(System.in);
			Connection conn=null;
			PreparedStatement selectSnoPrepare=null;
			PreparedStatement selectCnamaePrepare=null;
			PreparedStatement insertScPrepare=null;
			ResultSet selectSnoResultSet=null;
			ResultSet selectCnoResultSet=null;
			ResultSet selectSCResultSet=null;
			Statement statement=null;
			//Statement insetStatement=null;
			try {
				
				Class.forName("com.mysql.jdbc.Driver");//加载驱动
                 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/score?useUnicode=true&characterEncoding=UTF8", "root","root");
                 String sno;
                 boolean exi=false;
		       do {
				 System.out.println("请输入学生学号：");
				 sno=input.next();
				 String selectSno="select stdno,password from student where stdno=?";
				 selectSnoPrepare=conn.prepareStatement(selectSno);
				 selectSnoPrepare.setString(1, sno);
				 selectSnoResultSet=selectSnoPrepare.executeQuery();
				 if(selectSnoResultSet.next()){
					 String pass=selectSnoResultSet.getString(2);
					 System.out.println("请输入密码：");
					 String mypass=input.next();
					 if(pass.equals(mypass)){
						 String selectCno="select name,cursno from course";
						 statement=conn.createStatement();
						 selectCnoResultSet=statement.executeQuery(selectCno);
						 int count=1;
						 ArrayList<String> courseArry=new ArrayList<String>();
						 ArrayList<String> courseNumArry=new ArrayList<String>();
						
						 while(selectCnoResultSet.next()){
							 courseArry.add(selectCnoResultSet.getString(1));
							 courseNumArry.add(selectCnoResultSet.getString(2));
							// System.out.println(count+"."+selectCnoResultSet.getString(1));
							 count++;
						 }
						 Menu courseMenu=new Menu(courseArry);
						 do {
							 
							 courseMenu.munePrint();
							 System.out.println("选择所选课程(-1退出)：");
							 int courseChoice=input.nextInt();
							 if(courseChoice==-1) continue;
							 if(courseChoice>courseArry.size()){
								 System.out.println("输入错误！");
								 continue;
							 }
							 String scSql="select * from sc,course where sc.cursno=course.cursno and name=? and stdno=?";
							 selectCnamaePrepare=conn.prepareStatement(scSql);
							 selectCnamaePrepare.setString(1,courseArry.get(courseChoice-1));
							 selectCnamaePrepare.setString(2,sno);
							 selectSCResultSet=selectCnamaePrepare.executeQuery();
							 //System.out.println(courseArry.get(courseChoice-1)+sno);
							 if(selectSCResultSet.next()){
								 System.out.println("该课程已选！");
							 }
							 else{
								 String insertSql="insert into sc values(?,?,null)";
								 insertScPrepare=conn.prepareStatement(insertSql);
								 insertScPrepare.setString(1,courseNumArry.get(courseChoice-1));
								 insertScPrepare.setString(2,sno);
								 insertScPrepare.executeUpdate();
								 System.out.println("选课成功！"); 
							 }
						} while (true);
						 
					 }
					 else{
						 System.out.println("密码错误！");
						
					 }
				 }
				 else {
					System.out.println("学号不存在，请重新输入");
					
				}
			} while (!exi); 
			    
				
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				// TODO: handle exception
			}catch(SQLException e) {
				e.printStackTrace();
				// TODO: handle exception
			}finally {
				if(conn!=null){
					try {
						conn.close();
						//System.out.print("关闭成功");
					} catch (SQLException e2) {
						e2.printStackTrace();
						// TODO: handle exception
					}
					if(selectSnoPrepare!=null){
						try {
							selectSnoPrepare.close();
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
					}
					if(statement!=null){
						try {
							statement.close();
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
					}
					if(selectCnamaePrepare!=null){
						try {
							selectCnamaePrepare.close();
						} catch (SQLException e2) {
							e2.printStackTrace();
							// TODO: handle exception
						}
					}
				}
			}
			
		}
}
