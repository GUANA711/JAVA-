/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(用一句话描述该文件做什么) 

 * 

 * @author          赵官凌

 * @version         V1.0  

 * @Date           2019年12月4日 上午12:12:30
 */
package guanling.zhao.addstudent;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


import  java.sql.Statement;
import java.sql.Connection;




public class Test {
	
	 public static boolean dateJudge(String date ){
    	 String year;
    	 String month;
    	 String day;
          if(date.length()<10) return false;
          char[] dateArry=new char[10];
     	 dateArry=date.toCharArray();
          //System.out.println(date.substring(4, 5)+date.substring(7, 8));
    	 if(dateArry[4] != '-'|| dateArry[7] != '-'){
    		 //System.out.println("格式错误！");
    		 return false;
    	 }
    	 //int int_year=Integer.parseInt(year);
    	 year=date.substring(0, 4);
    	 month=date.substring(5,7);
    	 day=date.substring(8,10);
    	
    	 for(int i=0;i<date.length();i++){
    		 if(i==4 || i==7) continue;
    		 if(dateArry[i]<'0' || dateArry[i]> '9') return false;
    		
    			 
    	 }
    	
    	 int int_month=Integer.parseInt(month);
    	 int int_day=Integer.parseInt(day);
    	 if(int_month>12||int_month<1) return false;
    	 if(int_day<1||int_day>31) return false;
    		 
    	 
    	
    	 
    	 return true;
	 }
	
	
	
	public static void addStudent(Connection conn,PreparedStatement preparedStatement) throws SQLException{
		int personNum;
		Scanner input=new Scanner(System.in);
		System.out.println("请输入要插入的人数：");
		personNum=input.nextInt();
		//System.out.println("请依次输入学号、姓名、性别、出生日期(yyyy-mm-dd)、密码：");
		//PreparedStatement preparedStatement=null;
		while(personNum>0){
			    System.out.println("请依次输入学号、姓名、性别、出生日期(yyyy-mm-dd)、密码：");
		      	String sno=input.next();
		      	String sname=input.next();
		        String ssex=input.next();
		        
		        if(ssex.equals("男")||ssex.equals("女")){
		        	
		        }
		        else{
		        	System.out.println("性别只能为 ‘男’或‘女’");
		        	continue;
		        }
		        String date=input.next(); 
		        if(!dateJudge(date)){
		        	System.out.println("请按照yyy-mm-dd格式输入日期！");
		        	continue;
		        	
		        	
		        }
		        String pass=input.next();
		        String sql="insert into student values(?,?,?,?,?)";
		        preparedStatement=conn.prepareStatement(sql);
		        preparedStatement.setString(1,sno);
		        preparedStatement.setString(2,sname);
		        preparedStatement.setString(3,ssex);
		        preparedStatement.setString(4,date);
		        preparedStatement.setString(5,pass);
		        preparedStatement.executeUpdate();
		        
			   
			    personNum--;
		} 
	    	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
      public static void main(String[] args) {
		Connection conn=null;
		PreparedStatement preparedStatement=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");//加载驱动
			//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
		    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/score?useUnicode=true&characterEncoding=UTF8", "root","root");
		    //System.out.print("链接成功");
		    addStudent(conn, preparedStatement);
		    
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			// TODO: handle exception
		}catch(SQLException e) {
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			if(conn!=null){
				try {
					conn.close();
					//System.out.print("关闭成功");
				} catch (SQLException e2) {
					e2.printStackTrace();
					// TODO: handle exception
				}
				if(preparedStatement!=null){
					try {
						preparedStatement.close();
					} catch (SQLException e2) {
						e2.printStackTrace();
						// TODO: handle exception
					}
				}
			}
		}
		
	}
}
