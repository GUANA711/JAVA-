package guanling.zhao.diary;

public class Frame {
	

}
