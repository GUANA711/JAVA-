/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(用一句话描述该文件做什么) 

 * 

 * @author          赵官凌

 * @version         V1.0  

 * @Date           2019年12月8日 上午9:51:30
 */
package guanling.zhao.diary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import guanling.zhao.diary.Menu;
import guanling.zhao.diary.Date;
import guanling.zhao.diary.Diary;
import guanling.zhao.diary.mood;
import guanling.zhao.diary.weather;

public class Test {
      public static void main(String[] args) {
    	Connection conn=null;
  		PreparedStatement preparedStatement=null;
  		boolean isExite=false;
  		try {
  			
  			Class.forName("com.mysql.jdbc.Driver");//加载驱动
  			//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
  		    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/diary?useUnicode=true&characterEncoding=UTF8", "root","root");
  		   
  		  Scanner input=new Scanner(System.in);
  		  ArrayList<String> firstMenuContents=new ArrayList<String>();
  		  firstMenuContents.add("登录系统");
  		  firstMenuContents.add("系统设置");
  		  firstMenuContents.add("写日记");
  		  firstMenuContents.add("查找日记");
  		  firstMenuContents.add("退出系统");
  		
  		  ArrayList<String> secondMenuContents=new ArrayList<String>();
  		  secondMenuContents.add("天气 ");
  		  secondMenuContents.add("心情");
  		  secondMenuContents.add("标题");
		  secondMenuContents.add("日期范围");
		  secondMenuContents.add("日记内容关键词");
  		
  		  Menu firstMenu=new Menu(firstMenuContents);
      	  Menu secondMenu=new Menu(secondMenuContents);
  		   
      	  do {
      		firstMenu.munePrint();
			int firstChoice =input.nextInt();
			//firstMenu.munePrint();
			switch (firstChoice) {
			case 1:
				break;
			case 2:break;
			case 3:
				System.out.println("请输入日记题目");
				String title=input.next();
						
				System.out.println("请输入时间（YYY/MM/DD）:");
				String date=input.next();
				Date myDate=new Date(date);
				
				System.out.println("请选择心情:");
				mood myMood;
				System.out.println("1.happy  2.sad   3.normal");
				int moodChioce=input.nextInt();
				switch (moodChioce) {
				case 1:
					myMood=mood.happy;
					
					break;
				case 2:
					myMood=mood.sad;break;
			    case 3:
			    	myMood=mood.normal;break;
				default:
					System.out.println("输入错误！默认为happy");
					myMood=mood.happy;
					break;
				}
				
				System.out.println("请选择天气:");
				weather myWeather;
				System.out.println("1.sun  2.cloudy  3.rain  4.snow");
				int weatherChoice=input.nextInt();
				switch (weatherChoice) {
				case 1:
					myWeather=weather.sun;
					
					break;
				case 2:
					myWeather=weather.cloudy;break;
				case 3:
					myWeather=weather.rain;break;
				case 4:
				    myWeather=weather.snow;break;

				default:
					System.out.println("输入错误！默认为sun");
					myWeather=weather.sun;
					break;
				}
				System.out.println("请输入内容:");
				input.nextLine();
				String myContents=input.nextLine();
				Diary myDiary=new Diary(myDate,title,myContents,myWeather, myMood);
				//System.out.println(myDiary.toString());
				myDiary.sqlSave(conn, preparedStatement);
				
				
				
				break;
			case 4:
				secondMenu.munePrint();
				int secondChoice=input.nextInt();
				switch (secondChoice) {
				case 1:
					Diary.serchDiary(conn, preparedStatement,"weather");
					break;
				case 2:
					Diary.serchDiary(conn, preparedStatement,"mood");
					break;
				case 3:
					Diary.serchDiary(conn, preparedStatement,"title");
					break;
				case 4:
					Diary.serchDiary(conn, preparedStatement,"date");
					break;
				case 5:
					Diary.serchDiary(conn, preparedStatement,"key");
					 break;

				default:
					break;
				}
				
				break;
			case 5:
				isExite=true;
			default:
				break;
			}
      		  
      		  
      		  
		} while (!false);
  		    
  			
  			
  		} catch (ClassNotFoundException e) {
  			e.printStackTrace();
  			// TODO: handle exception
  		}catch(SQLException e) {
  			e.printStackTrace();
  			// TODO: handle exception
  		}finally {
  			if(conn!=null){
  				try {
  					conn.close();
  					//System.out.print("关闭成功");
  				} catch (SQLException e2) {
  					e2.printStackTrace();
  					// TODO: handle exception
  				}
  				if(preparedStatement!=null){
  					try {
  						preparedStatement.close();
  					} catch (SQLException e2) {
  						e2.printStackTrace();
  						// TODO: handle exception
  					}
  				}
  			}
  		}
  		
	}
}
