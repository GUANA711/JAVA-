package guanling.zhao.diary;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Year;
import java.util.ArrayList;
import java.util.Scanner;

import javax.print.DocFlavor.INPUT_STREAM;

import org.omg.CORBA.StringHolder;

import com.mysql.jdbc.StreamingNotifiable;

import guanling.zhao.diary.mood;
import guanling.zhao.diary.weather;
import guanling.zhao.diary.Date;

enum weather{sun,cloudy,rain,snow};
enum mood{happy,sad,normal}
public class Diary implements Comparable {
	private Date date;
	private String title;
	private String contents;
	private weather weather;
	private mood mood;
	
	public Diary(Date date,String title,String contents,weather weather,mood mood){ 
    	this.date=date;
    	this.title=title;
    	this.contents=contents;
    	this.weather=weather;
    	this.mood=mood;
    	
    }
    
     public String toString(){
    	return date.getDate()+" "+weather+" "+mood+" "+title+" "+contents;
    }
     
     public String getTitle(){
    	 return title;
     }
     
     public Date getDate(){
    	 return this.date;
     }
     
     public String getContens(){
    	 return contents;
     }

	@Override
	public int compareTo(Object otherDiary) {
		Diary myDiary=(Diary)otherDiary;
	
	    if(date.getYear()==myDiary.getDate().getYear()){
	    	if(date.getMonth()==myDiary.getDate().getMonth()){
	    		return date.getdday()-myDiary.getDate().getdday();
	    	}
	    	else {
				return date.getMonth()-myDiary.getDate().getMonth();
			}
	    }
	    else {
			return date.getYear()-myDiary.getDate().getYear();
		}
		
		
		
	}
	
	
     
   public void sqlSave(Connection conn,PreparedStatement preparedStatement) throws SQLException{
	   String sql="insert into diary values(?,?,?,?,?)";
	   preparedStatement=conn.prepareStatement(sql);
       preparedStatement.setString(1,date.getDate());
       preparedStatement.setString(2,title);
       preparedStatement.setString(3,contents);
       preparedStatement.setString(4,weather.toString());
       preparedStatement.setString(5,mood.toString());
       preparedStatement.execute();
	   
	   
   }
   
   public static void diaryList(Connection conn,PreparedStatement preparedStatement) throws SQLException{
	   String sql="select title,date,weather,mood from diary";
	   ResultSet pResultSet=null;
	   int count=1;
	   preparedStatement=conn.prepareStatement(sql);
	   pResultSet=preparedStatement.executeQuery();
	   while(pResultSet.next()){
		   System.out.println(count+'.'+' '+pResultSet.getString(1)+' '+pResultSet.getString(2)+' '+pResultSet.getString(3)+' '+pResultSet.getString(4));
	   }
   }
   
   public static boolean serchDiary(Connection conn,PreparedStatement preparedStatement,String type) throws SQLException{
	   String sql;
	   String myChoice;
	   Scanner input=new Scanner(System.in);
	   ArrayList<String> diaryTitle=new ArrayList<String>();
	   ArrayList<String> diaryToString=new ArrayList<String>();
	   int index=1;
	   int diaryChoice;
	   ResultSet resultSet=null;
	   if(type.equals("mood")){
		   System.out.println("请选择心情(happy,sad,normal)：");
		   myChoice=input.next();
		   sql="select * from diary where mood=?";
		   preparedStatement=conn.prepareStatement(sql);
		   preparedStatement.setString(1,myChoice);
		   resultSet=preparedStatement.executeQuery();
		   
	   }
	   if(type.equals("weather")){
		   System.out.println("请选择天气(sun,cloudy,rain,snow)：");
		   myChoice=input.next();
		   sql="select * from diary where weather=?";
		   preparedStatement=conn.prepareStatement(sql);
		   preparedStatement.setString(1,myChoice);
		   resultSet=preparedStatement.executeQuery();
		   
	   }
	   if(type.equals("title")){
		   System.out.println("请输入标题：");
		   myChoice=input.next();
		   sql="select * from diary where title=?";
		   preparedStatement=conn.prepareStatement(sql);
		   preparedStatement.setString(1,myChoice);
		   resultSet=preparedStatement.executeQuery();
		   
	   }
	   
	   if(type.equals("date")){
		  
			   System.out.println("请输入起始日期（yyyy/mm/dd）：");
			   String bString=input.next();
			   Date bDate=new Date(bString);
			   System.out.println("请输入结束日期（yyyy/mm/dd）：");
			   String eString=input.next();
			   Date eDate=new Date(eString);
			   if(!bDate.dateJudge() || !eDate.dateJudge()){
				   System.out.println("日期格式输入错误！");
				   return false;
			   }
			   else {
				   sql="select * from diary where date>=? and date<=?";
				   preparedStatement=conn.prepareStatement(sql);
				   preparedStatement.setString(1,bDate.getDate());
				   preparedStatement.setString(2,eDate.getDate());
				   
				   resultSet=preparedStatement.executeQuery();
			}
			   
		   
		   
		   
	   }
	   
	   if(type.equals("key")){
		   System.out.println("请输入日记关键词：");
		   myChoice=input.next();
		   sql="select * from diary where contents like ?";
		   preparedStatement=conn.prepareStatement(sql);
		   preparedStatement.setString(1,'%'+myChoice+'%');
		   resultSet=preparedStatement.executeQuery();
	   }
	   
	   if(!resultSet.next()){
		   System.out.println("没有符合该条件的日记！");
	   }
	   else{
		    System.out.println(index+". "+resultSet.getString(2));
			diaryToString.add(resultSet.getString(1)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(3));
			diaryTitle.add(resultSet.getString(2));
			index++;
		   
		   while (resultSet.next()) {
				
				System.out.println(index+". "+resultSet.getString(2));
				diaryToString.add(resultSet.getString(1)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(3));
				diaryTitle.add(resultSet.getString(2));
				index++;
			}
			   System.out.println("请选择日记，查看内容：");
			   diaryChoice=input.nextInt();
			   System.out.println(diaryToString.get(diaryChoice-1));
		   }
	   return true;
		     
	   }
	   
	  
	 

}
