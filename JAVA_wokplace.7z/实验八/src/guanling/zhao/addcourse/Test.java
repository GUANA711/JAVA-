
/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(用一句话描述该文件做什么) 

 * 

 * @author          赵官凌

 * @version         V1.0  

 * @Date           2019年12月4日 上午9:51:30
 */package guanling.zhao.addcourse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Test {
	public static void addcourse(Connection conn,PreparedStatement preparedStatement) throws SQLException{
		int courseNum;
		Scanner input=new Scanner(System.in);
		System.out.println("请输入要插入的课程数：");
		courseNum=input.nextInt();
		//System.out.println("请依次输入学号、姓名、性别、出生日期(yyyy-mm-dd)、密码：");
		//PreparedStatement preparedStatement=null;
		while(courseNum>0){
			    System.out.println("请依次输入课程号、课程名 、学分（必须在 0 到 5 分之间）");
		      	String cno=input.next();
		      	String cname=input.next();
		        String cridt=input.next();
		        
		        char[] cridtChar=cridt.toCharArray();
		        
		       if(cridtChar[0]<'0'||cridtChar[0]>'5'){
		    	   System.out.println("学分必须在 0 到 5 分之间）");
		    	   continue;
		       }
		       
		        
		        String sql="insert into course values(?,?,?)";
		        preparedStatement=conn.prepareStatement(sql);
		        preparedStatement.setString(1,cno);
		        preparedStatement.setString(2,cname);
		        preparedStatement.setString(3,cridt);
		        preparedStatement.executeUpdate();
		        
			   
		        courseNum--;
		} 
	    	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
      public static void main(String[] args) {
		Connection conn=null;
		PreparedStatement preparedStatement=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");//加载驱动
			//String url="jdbc:mysql://localhost:3306/score?user=root&password=root";
		    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/score?useUnicode=true&characterEncoding=UTF8", "root","root");
		    //System.out.print("链接成功");
		    addcourse(conn, preparedStatement);
		    
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			// TODO: handle exception
		}catch(SQLException e) {
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			if(conn!=null){
				try {
					conn.close();
					//System.out.print("关闭成功");
				} catch (SQLException e2) {
					e2.printStackTrace();
					// TODO: handle exception
				}
				if(preparedStatement!=null){
					try {
						preparedStatement.close();
					} catch (SQLException e2) {
						e2.printStackTrace();
						// TODO: handle exception
					}
				}
			}
		}
		
	}
}
