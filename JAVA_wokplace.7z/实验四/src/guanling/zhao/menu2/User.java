package guanling.zhao.menu2;

import java.nio.file.attribute.UserPrincipalLookupService;

import javax.security.auth.login.LoginContext;

public class User {
	static public int userCount=0;
	public String userName="null";
	public String showName="null";
	public String password="null";
	public String mail="null";
	public String anwser="null";
	
    public User(String userName,String showName,String password,String mail,String answer){
    	this.userName=userName;
    	this.showName=showName;
    	this.password=password;
    	
    	this.mail=mail;
    	this.anwser=answer;
    }
	

    public boolean login(String[] userArry,String[] passArry) {
    	int position=0;
    	int isRight=0;
		for(int i=0;i<userArry.length;i++){
			if(userArry[i].equalsIgnoreCase(userName)){
				isRight=1;
				position=i;
				break;
			}
		}
		if(isRight==0){
			System.out.println("�û���������");
			return false;
		}
		else{
			
			if(passArry[position].equalsIgnoreCase(password)){
				return true;
			}
			else {
				System.err.println("����������������룡");
				return false;
			}
		}
		
		
    }
    
}
