
package guanling.zhao.line;

import javax.swing.text.html.HTMLDocument.HTMLReader.IsindexAction;

public class Point2D {
    private double x;
    private double y;
    
    public Point2D(double x,double y) {
    	this.x=x;
    	this.y=y;
    }
    
    public boolean equals(Object p1) {
    	if(p1==null){
    		System.out.println("�Ƚ϶�����Ϊ��");
    		return false;
    	}
    	if (p1 instanceof  Point2D){
    		Point2D p=(Point2D)p1;
    		if(this.x==p.x&&this.y==p.y) {
        		return true;
        	}
        	else {
    			return false;
    		}
        }
    	return false;
    	
    }
    
    
    public void setx(double x) {
    	this.x=x;
    }
    public void sety(double y) {
    	this.y=y;
    }
    public double  getx() {
       return this.x;	
    }
    
    public double  gety() {
        return this.y;	
     }

    
    
    
    
    
    
}
