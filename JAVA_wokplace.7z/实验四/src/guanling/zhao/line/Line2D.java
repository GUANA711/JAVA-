package guanling.zhao.line;

public class Line2D {
    public double a=0;
    public double b=0;
    public double c=0;
    public double slope=0;//�ж�����
    public Point2D p1=new Point2D(0,0);
    public Point2D p2=new Point2D(0,0);
    public double interceptX=0;//
    public double  interceptY=0;
    public boolean isLine=true;
    public double bpoint=0;
    
    //һ��ʽ��������
    public Line2D(double a,double b,double c) {
    	this.a=a;
    	this.b=b;
    	this.c=c;
    	if(b==0){
    		this.slope=Double.NEGATIVE_INFINITY;
    	}
    	else {
    		this.slope=0-(a/b);
		}
    	
    	this.bpoint=0-(c/b);
    }
    //����ʽ��������
    public Line2D(Point2D point1,Point2D point2) {
    	
    	if(point1.equals(point2)){
    		this.isLine=false;
    		System.out.println("��ֱ�߲��Ϸ�");
    	}
    	if(point1!=null && point2!=null){
    		p1.setx(point1.getx());
        	p1.sety(point1.gety());
        	p2.setx(point2.getx());
        	p2.sety(point2.gety());
        	if(this.p1.gety()-this.p2.gety()==0){
        		this.slope=Double.NEGATIVE_INFINITY;
        	}
        	else{
        		this.slope=(this.p1.getx()-this.p2.getx())/(this.p1.gety()-this.p2.gety());
        	}
        
        	this.bpoint=point1.gety()-this.slope*point1.getx();
        	
    	}
    	else {
			System.out.print("�㲻��Ϊ�գ�");
			this.isLine=false;
		}    	
    }
    //��бʽ��������
    public Line2D(Point2D point,double slope) {
    	if(point==null){
    		System.out.print("�㲻��Ϊ�գ�");
			this.isLine=false;
    	}
    	p1.setx(point.getx());
    	p1.sety(point.gety());
    	this.slope=slope;
    	this.bpoint=point.gety()-this.slope*point.getx();
    }
    
    //�ؾ�ʽ
    public Line2D(double  interceptX,double  interceptY) {
    	this.interceptX= interceptX;
    	this.interceptY= interceptY;
    	if(interceptX==0){
    		this.slope=Double.NEGATIVE_INFINITY;
    	}
    	else{
    		this.slope=0-interceptY/interceptX;
    	}
    	this.bpoint=this.interceptY;
    	
    	
    }
    
    public void print(){
    	System.out.println("slope:"+slope);
    	System.out.println("bpoint:"+bpoint);
    	
    	
    }
   
    public boolean equals(Object obj){
    	if(obj==null){
    		System.out.println("�Ƚ϶�����Ϊ��");
    		return false;
    	}
    	if(obj instanceof Line2D){
    		Line2D l=(Line2D) obj;
    		if(this.isLine==false || l.isLine==false){
        		System.out.println("ֱ�߲��Ϸ�,�޷��Ƚ�");
        		return false;
        	}
        	if(this.slope==l.slope){
        		if(l.bpoint == this.bpoint){
        			return true;
        		}
        		else {
    				return false;
    			}
        	}
        	else {
    			return false;
    		}
    	}
    	return false;
    }
    
    public boolean parallel(Line2D l){
    	if(this.equals(l)){
    		return false;
    	}
    	else if(this.slope==l.slope){
    		return true;
    	}
    	else {
			return false;
		}
    	
    }
}
