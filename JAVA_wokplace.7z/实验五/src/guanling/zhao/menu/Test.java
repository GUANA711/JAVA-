/**
 * 

 * @ClassName:     Test.java

 * @Description:   TODO(��һ�仰�������ļ���ʲô) 

 * 

 * @author          �Թ���

 * @version         V1.0  

 * @Date           2019��10��19�� ����4:51:30
 */

package guanling.zhao.menu;

import java.util.Scanner;
import java.util.Date;
import java.util.Formatter;
import java.util.Calendar;
import java.awt.Choice;
import java.text.SimpleDateFormat;


public class Test{
	static boolean isLogin=false;
	static String loginUser;
	
    public static void main(String[] args) {
    	int choiceMain;
    	int choiceLogin;
    	int choiceRegist;
    	int registFlag=0;
        int loginFlag=1;
    	User userSave=new User("null", "null", "null", "null", "null");
    	String[] userName=new String[10];
    	String[] showName=new String[10];
    	String[] password=new String[10];
    	String[] mail=new String[10];
    	String[] passQuestion=new String[10];
    	String[] passAssur=new String[10];
    	String inputName;
    	String inputPass;
    	String inputAnser;
    	String anserName;
    	String newPassAsrur;
    	String diaryDate;
    	String diaryTitle;
    	String diaryContents;
    	
    	int weatherint;
    	int moodint;
    	weather choiceWeather=weather.cloudy;
    	mood choiceMood=mood.happy;
    	
    	Scanner input= new Scanner(System.in);
    
		do {
			Menu.showMainMenu();
			choiceMain=input.nextInt();
			switch (choiceMain) {
			case 1:
				do {
					Menu. showRegistMenu();
				    choiceRegist=input.nextInt();
				    switch (choiceRegist) {
					case 1:
				  
						System.out.println("�������û�����");
					    userName[User.userCount]=input.next();
						System.out.println("��������ʾ����");
						showName[User.userCount]=input.next();
						System.out.println("���������룺");
					    password[User.userCount]=input.next();
						System.out.println("ȷ�����룺");
					    passAssur[User.userCount]=input.next();
						System.out.println("���������䣺");
						 mail[User.userCount]=input.next();
					       
						if( Menu.userNameJudge(userName[User.userCount])&& Menu.showNameJudge(showName[User.userCount])&&Menu.passwordJudge(password[User.userCount], passAssur[User.userCount])&&Menu.mailJudge(mail[User.userCount])){
							
							passQuestion[User.userCount]=Menu.passQuetion();
							if (Menu.arithmetic()) {
								
								userSave.userName=userName[User.userCount];
								userSave.showName=showName[User.userCount];
								userSave.password=password[User.userCount];
								userSave.mail=mail[User.userCount];
								userSave.anwser=passQuestion[User.userCount];
								System.out.println("username["+User.userCount+"]="+"'"+userName[User.userCount]+"'");
								System.out.println("password["+User.userCount+"]="+"'"+password[User.userCount]+"'");
								registFlag=1;
						        User.userCount++;	
								break;
							}
							else {
								break;
							}
							
						     	
						}
						else {
							break;
						}
					 
					    	
					case 2:	
						do {
							System.out.println("�������û���");
							inputName=input.next();
							System.out.println("���������룺");
							inputPass=input.next();
							
						} while (!userSave.login(userName, password,inputName));
						System.out.println("��¼�ɹ���");
						isLogin=true;
					    loginUser=inputName;

						boolean flag=true;
						do {
							Menu.showLoginMenu(showName, userName, inputName);
							choiceLogin=input.nextInt();
							switch (choiceLogin) {
							case 1:
								loginFlag=0;
								flag=false;
								isLogin=false;
								break;
							case 2:
								System.out.println("����ִ��ĳ���ܡ���");
							case 3:
								SimpleDateFormat format = new SimpleDateFormat("yyyy/mm/dd");
								Date now = new Date();
								String defaultDate= format.format( now );
								System.out.println("��ѡ��������");
								System.out.println("1.����  2.����  3.��  4.ѩ");
							    weatherint=input.nextInt();
							    switch (weatherint) {
								case 1:
									choiceWeather=weather.sun;
									
									break;
								case 2:
									choiceWeather=weather.cloudy;
									break;
								case 3:
									choiceWeather=weather.rain;
								    break;
								case 4:
									choiceWeather=weather.snow;

								default:
									break;
								}
							    
							    System.out.println("��ѡ�����飺");
								System.out.println("1.����  2.����  3.һ��  ");
								moodint=input.nextInt();
								switch (moodint) {
								case 1:
									choiceMood=mood.happy;
									break;
								case 2:
									choiceMood=mood.sad;
									break;
								case 3:	
									choiceMood=mood.normal;
									break;

								default:
									break;
								}
								System.out.println("������ʱ�� (yyy/mm/dd)��");
								diaryDate=input.next();
								while (!guanling.zhao.menu.Date.dateJudge(diaryDate)){
									System.out.println("��ʽ�������������룺");
                                     diaryDate=input.next();
								}
								guanling.zhao.menu.Date diDate=new guanling.zhao.menu.Date(diaryDate);	
								System.out.println("��������⣺");
								diaryTitle=input.next();
								
								while (diaryTitle.length()>12){
									System.out.println("��Ŀ���ܳ���12���ַ���");
									diaryTitle=input.next();
								}
								System.out.println("�������ռ����ݣ�");
								diaryContents=input.next();
								Diary diary=new Diary(diDate, diaryTitle, diaryContents, choiceWeather, choiceMood);
								System.out.println(diary.toString());
								break;
								
							case 4:
							case 5:
								System.out.println("����ִ��ĳ���ܡ���");
								
								break;

							default:
								break;
							}
						} while (flag);
						
						break;
						
					case 3:
						Menu.showPassQuestion();
						input.nextInt();
						System.out.println("�������û�����");
						anserName=input.next();
					    System.out.println("����𰸣�");
					    inputAnser=input.next();
					   
					    if( Menu.findPassword(userName, passQuestion, anserName, inputAnser)){
					    	String newPassword;
					    	System.out.println("�����������룺");
					    	newPassword=input.next();
					    	System.out.println("ȷ�����룺");
					    	newPassAsrur=input.next();
					    	if(Menu.passwordJudge(newPassword, newPassAsrur)){
					    		Menu.reNewPassord(userName, password, anserName, newPassword);
					    		break;
					    	}
					    
					    	
					    	
					    	break;
					    }
					    else {
							break;
						}
					    

					default:
						break;
					}
					
				} while (registFlag==1&&loginFlag==1);
				
			
			    break;
			case 2:
				System.err.println("�û�δ��¼�����ȵ�¼��");
				break;
			case 3:
				
				
				
			    
				
				
			case 4:
				System.err.println("�û�δ��¼�����ȵ�¼��");
				break;
			case 5:	
				System.out.println("ллʹ�ã��ټ���");
				System.exit(0);
				break;
			default:
				System.out.println("����������������룡");
				break;
			}
		} while (true);
	}
}
