package guanling.zhao.menu;

public class Date {
    public String date;
    
    public Date(String date){
    	this.date=date;
    }
    //���ڸ�ʽΪ��YYYY/MM/DD
     public static boolean dateJudge(String date){
    	 String year;
    	 String month;
    	 String day;
          if(date.length()<10) return false;
          char[] dateArry=new char[10];
     	 dateArry=date.toCharArray();
          //System.out.println(date.substring(4, 5)+date.substring(7, 8));
    	 if(dateArry[4] != '/' || dateArry[7] != '/'){
    		 //System.out.println("��ʽ����");
    		 return false;
    	 }
    	 //int int_year=Integer.parseInt(year);
    	 year=date.substring(0, 4);
    	 month=date.substring(5,7);
    	 day=date.substring(8,10);
    	
    	 for(int i=0;i<date.length();i++){
    		 if(i==4 || i==7 ) continue;
    		 if(dateArry[i]<'0' || dateArry[i]> '9') return false;
    	 }
    	
    	 int int_month=Integer.parseInt(month);
    	 int int_day=Integer.parseInt(day);
    	 if(int_month>12||int_month<1) return false;
    	 if(int_day<1||int_day>31) return false;
    		 
    	 
    	
    	 
    	 return true;
    	 
     }
}
