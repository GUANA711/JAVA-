package guanling.zhao.menu;
enum weather{sun,cloudy,rain,snow};
enum mood{happy,sad,normal}
public class Diary {
	public Date day;
	public String title;
	public String contents;
	public weather weather;
	public mood mood;
	
    public Diary(Date day,String title,String contents,weather weather,mood mood){ 
    	this.day=day;
    	this.title=title;
    	this.contents=contents;
    	this.weather=weather;
    	this.mood=mood;
    }
    
     public String toString(){
    	return day.date+" "+weather+" "+mood+" "+title+" "+contents;
    }
	

}
