package guanling.zhao.draw;

public interface SolidColorable {
    public void paintShape();
    public boolean isShapePainted();
}
