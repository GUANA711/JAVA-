package guanling.zhao.draw;

public interface BorderColorable {
   public void paintBorder();
   public boolean isBorderPainted();
}
