package guanling.zhao.draw;

public class Rectangle extends Shape2D implements BorderColorable,SolidColorable
{
	public double side1;
	public double side2;
	public boolean isPaimtedBoder=false;
	public boolean isPainedShape=false;
	
    public Rectangle(double side1,double side2) {
		// TODO Auto-generated constructor stub
    	this.side1=side1;
    	this.side2=side2;
	}
	


	@Override
	public void paintShape() {
		// TODO Auto-generated method stub
		isPainedShape=true;
		System.out.println("�Ѿ������ν�����ɫ");
		
	}

	@Override
	public boolean isShapePainted() {
		// TODO Auto-generated method stub
		if(isPainedShape) return true;
		else {
			return false;
		}
			
		
	}

	@Override
	public void paintBorder() {
		// TODO Auto-generated method stub
		isPaimtedBoder=true;
		System.out.println("�Ѿ������εı߽�����ɫ");
		
	}

	@Override
	public boolean isBorderPainted() {
		// TODO Auto-generated method stub
		if(isPaimtedBoder) return true;
		else
		return false;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return 2*(side1+side2);
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return side1*side2;
	}

}
