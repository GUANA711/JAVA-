package guanling.zhao.draw;

public class Square extends Rectangle {
	
     public Square(double myside) {
		super(myside, myside);
		//this.myside=myside;
		// TODO Auto-generated constructor stub
	}

	
     
}
