package guanling.zhao.draw;

public abstract class Shape2D {
     public abstract double getPerimeter();
     public abstract double getArea();
}
