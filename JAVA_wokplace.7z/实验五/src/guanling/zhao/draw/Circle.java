package guanling.zhao.draw;

public class Circle extends Shape2D implements BorderColorable{
    public double radius;
    public boolean isPaintedBorder=false;

	
	public Circle(double radius){
	    this.radius=radius;	
	}
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return 2*3.14*radius;
	}

	
	public double getArea() {
		// TODO Auto-generated method stub
		return 3.14*radius*radius;
	}
	@Override
	public void paintBorder() {
		// TODO Auto-generated method stub
		this.isPaintedBorder=true;
		System.out.println("�Ѿ���Բ�εı߽�����ɫ");
		
	}
	@Override
	public boolean isBorderPainted() {
		// TODO Auto-generated method stub
		if(this.isPaintedBorder) return true;
		else return false;
	}
    
}
