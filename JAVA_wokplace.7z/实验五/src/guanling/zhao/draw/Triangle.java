package guanling.zhao.draw;


public class Triangle extends Shape2D implements SolidColorable{
	public double side1;
	public double side2;
	public double side3;
	public boolean isPaientedShape=false;
	
	public  Triangle(double side1,double side2,double side3) {
		this.side1=side1;
		this.side2=side2;
		this.side3=side3;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void paintShape() {
		// TODO Auto-generated method stub
		isPaientedShape=true;
		System.out.println("�Ѿ��������ν�����ɫ");
		
	}

	@Override
	public boolean isShapePainted() {
		// TODO Auto-generated method stub
		if(this.isPaientedShape) return true;
		else
		return false;
	}

	
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return this.side1+this.side2+this.side3;
	}

	
	public double getArea() {
		// TODO Auto-generated method stub
		double s;
		s=(side1+side2+side3)/2;
		return Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
	}

}
