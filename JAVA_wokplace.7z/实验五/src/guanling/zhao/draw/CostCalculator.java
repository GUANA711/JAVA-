package guanling.zhao.draw;

public class CostCalculator {
	public double borderCost;
	public double solidCost;
    public CostCalculator(double borderCost,double solidCost){
    	this.borderCost=borderCost;
    	this.solidCost=solidCost;
    }
    public double calculate(Shape2D shape){
    	
    		//shape=(Circle)shape;
    		return shape.getArea()*solidCost+shape.getPerimeter()*borderCost;
    	
    }
}
